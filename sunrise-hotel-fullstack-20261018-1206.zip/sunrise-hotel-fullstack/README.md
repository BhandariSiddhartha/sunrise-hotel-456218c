# Sunrise Hotels & Resorts — Full-Stack Website

Sunrise Hotels website with a connected Express API and SQLite database for local development.

**Frontend:** The supplied Sunrise Hotels page is served by the Express app at `/`.

**Backend:** Node.js + Express + TypeScript + Prisma ORM

**Database:** SQLite (local dev) / PostgreSQL (production via Supabase)

---

## 📁 Project Structure

```
sunrise-hotel-fullstack/
├── server/
│   ├── public/             # Connected website and amenity photos
│   ├── src/
│   │   ├── config/         # Configuration (env, db, logger)
│   │   ├── controllers/    # Route controllers
│   │   ├── middleware/     # Auth, validation, error handling, rate limiting
│   │   ├── routes/v1/      # API v1 routes
│   │   ├── services/       # Business logic (booking, email, payment, chatbot)
│   │   ├── types/          # TypeScript types
│   │   └── index.ts        # Server entry point
│   ├── prisma/
│   │   ├── schema.prisma   # Database schema
│   │   ├── seed.ts         # Demo data seed script
│   │   └── migrations/     # Prisma migration files
│   ├── tests/              # Automated tests
│   ├── .env.example        # Environment variables template
│   ├── package.json
│   └── tsconfig.json
├── package.json            # Root workspace config
└── README.md
```

---

## 🚀 Quick Start (Development)

### 1. Install dependencies

```bash
cd sunrise-hotel-fullstack
npm install
```

### 2. Configure environment

Copy `.env.example` to `.env` and update values:

```bash
cp server/.env.example server/.env
```

Edit `server/.env` with your settings. At minimum:
- `DATABASE_URL` — SQLite for local dev: `file:./dev.db`
- `SESSION_SECRET` — long random string for session signing
- `ADMIN_EMAIL` / `ADMIN_PASSWORD` — initial admin credentials

### 3. Set up the database

```bash
# Generate Prisma client
npm run prisma:generate

# Create and apply migrations
npm run prisma:migrate:dev

# Seed demo data
npm run prisma:seed
```

> ⚠️ Demo credentials: `admin@sunrisehotel.example` / `change-me-in-production`  
> Change these before production!

### 4. Start the website and API

```bash
npm run dev
```

Website: http://localhost:4000  
API health: http://localhost:4000/api/v1/health

---

## 📦 Available Scripts

| Script | Description |
|---|---|
| `npm run dev` | Start dev server with tsx watch |
| `npm run build` | TypeScript compile to `dist/` |
| `npm start` | Run production server (`node dist/index.js`) |
| `npm run prisma:generate` | Generate Prisma client |
| `npm run prisma:migrate:dev` | Create & apply dev migration |
| `npm run prisma:migrate:deploy` | Apply migrations (production) |
| `npm run prisma:seed` | Seed demo data |
| `npm test` | Run test suite |

---

## 🔐 Security

- **Passwords:** bcrypt hashed (salt 12)
- **Sessions:** HTTP-only, SameSite=Lax, Secure cookies (production)
- **CORS:** Restricted to `CLIENT_URL` origin
- **Rate limiting:** Login (10/15min), booking (20/15min), contact (15/15min), chatbot (30/min)
- **Validation:** Zod schemas on all inputs
- **Headers:** Helmet (HSTS, CSP, X-Content-Type-Options, etc.)
- **SQL injection:** Prisma parameterized queries
- **Logging:** pino with secret redaction (passwords, tokens, keys)

---

## 📡 API Documentation (v1)

Base path: `/api/v1`

### Public Endpoints

| Method | Endpoint | Description |
|---|---|---|
| GET | `/health` | Health check |
| GET | `/rooms` | List active rooms |
| GET | `/rooms/:id` | Room detail |
| GET | `/rooms/availability` | Check availability (query: checkIn, checkOut, guests, roomType) |
| POST | `/bookings` | Create booking (idempotency key supported) |
| POST | `/bookings/verify` | Public booking lookup (body: reference, email) |
| POST | `/bookings/:reference/cancel` | Cancel booking (body: email, reason?) |
| POST | `/dining-reservations` | Create dining reservation |
| POST | `/contact` | Send contact message |
| GET | `/reviews` | List approved reviews |
| POST | `/reviews` | Submit review (unapproved, moderation required) |
| GET | `/offers` | List active offers |
| POST | `/chatbot` | Hotel assistant Q&A (rate limited) |

### Admin Endpoints (require authentication + RBAC)

| Method | Endpoint | Roles |
|---|---|---|
| POST | `/admin/auth/login` | Public (rate limited) |
| POST | `/admin/auth/logout` | Authenticated |
| GET | `/admin/auth/me` | Authenticated |
| POST | `/admin/rooms` | SUPER_ADMIN, ADMIN |
| PATCH | `/admin/rooms/:id` | SUPER_ADMIN, ADMIN |
| DELETE | `/admin/rooms/:id` | SUPER_ADMIN |
| GET | `/admin/bookings` | Authenticated |
| PATCH | `/admin/bookings/:id/status` | Authenticated |
| GET | `/admin/dining-reservations` | Authenticated |
| PATCH | `/admin/dining-reservations/:id/status` | Authenticated |
| GET | `/admin/contact-messages` | Authenticated |
| PATCH | `/admin/contact-messages/:id/read` | Authenticated |
| GET | `/admin/reviews` | Authenticated |
| PATCH | `/admin/reviews/:id/approve` | Authenticated |
| POST | `/admin/offers` | SUPER_ADMIN, ADMIN |
| PATCH | `/admin/offers/:id` | SUPER_ADMIN, ADMIN |
| DELETE | `/admin/offers/:id` | SUPER_ADMIN |
| GET | `/admin/dashboard/stats` | Authenticated |
| GET | `/admin/occupancy` | Authenticated |

### Roles

- `SUPER_ADMIN` — Full access (including delete)
- `ADMIN` — Create/update access
- `STAFF` — Read-only access

---

## Frontend integration

The page is served from the same origin as the API, so no separate frontend URL or CORS setup is needed for local use. Availability and pricing come from the database. Booking requests, dining reservations, contact messages, and chatbot questions are sent to the API. Payments are not enabled unless a payment provider is configured.

---

## 📧 Email & Payments (Optional)

### Email

Configure SMTP in `.env`:
```
SMTP_HOST=smtp.example.com
SMTP_PORT=587
SMTP_USER=user
SMTP_PASS=pass
SMTP_FROM=noreply@yourdomain.com
```

When configured: booking confirmations, cancellations, dining confirmations, contact receipts are sent.  
When not configured: emails are skipped gracefully (logged, not sent).

### Payments (Razorpay / Stripe)

Configure in `.env`:
```
PAYMENT_PROVIDER=razorpay  # or stripe
RAZORPAY_KEY_ID=...
RAZORPAY_KEY_SECRET=...
# or
STRIPE_SECRET_KEY=...
STRIPE_WEBHOOK_SECRET=...
```

When configured: payment orders created, webhooks verified, payment status tracked separately from booking status.  
When not configured: `PAYMENT_PROVIDER=none`, no payment flow.

**Never store raw card details.** Webhook signatures verified. Duplicate webhook events handled idempotently.

---

## 🤖 Chatbot

The Sunrise Assistant answers questions about hotel information (rooms, amenities, dining, policies, offers, contact).

- **Rule-based fallback:** Always available, no API key needed
- **AI provider (optional):** Set `AI_PROVIDER=openai` or `anthropic` with API key
- **Rate limited:** 30 requests/minute
- **Never exposes:** guest data, admin data, private bookings
- **Never invents:** availability, prices, reservations

---

## 🗄️ Database

### Local development (SQLite)

```bash
npm run prisma:migrate:dev   # Create migration + apply
npm run prisma:seed          # Seed demo data
```

### Production (PostgreSQL / Supabase)

1. Change `provider` in `schema.prisma` to `"postgresql"`
2. Set `DATABASE_URL` to your PostgreSQL connection string
3. Run `npm run prisma:migrate:deploy` on deployment
4. Seed admin user via environment variables

### Migrations

Migration files are in `server/prisma/migrations/`. To create a new migration:

```bash
npx prisma migrate dev --name your_migration_name
```

---

## 🏗️ Deployment

### Frontend (same server)

The Express server serves `server/public/` at the root URL. Deploy the frontend and API together, or host the frontend separately and configure the backend CORS origin.

### Backend (Render)

1. Connect your GitHub repo to Render
2. Set environment variables in Render dashboard
3. Build command: `npm install && npm run build` (in server/)
4. Start command: `npm start` (in server/)
5. Add `prisma migrate deploy` as a release step or build step

### Required environment variables (production)

| Variable | Description |
|---|---|
| `DATABASE_URL` | PostgreSQL connection string |
| `SESSION_SECRET` | Long random secret |
| `ADMIN_EMAIL` | Initial admin email |
| `ADMIN_PASSWORD` | Initial admin password (change after first login) |
| `CLIENT_URL` | `https://sunrise-hotel-0e28dc.netlify.app` |
| `NODE_ENV` | `production` |

**Never commit `.env` with real values.** `.env.example` contains placeholders only.

---

## 🧪 Testing

```bash
npm test
```

Tests run against an isolated test database. Test suites cover:
- Rooms CRUD & availability
- Booking creation, verification, cancellation
- Idempotency (duplicate submission prevention)
- Dining reservations
- Contact messages
- Reviews (public + moderation)
- Offers
- Admin authentication & RBAC

---

## 📋 Admin Dashboard

A protected admin interface should be built at `/admin` on the frontend, consuming the admin API endpoints. Features:
- Dashboard summary (booking counts, revenue)
- Room management (CRUD)
- Booking management (list, filter, status updates)
- Dining reservation management
- Contact message management
- Review moderation
- Offer management
- Occupancy reports

All endpoints require authentication + appropriate role.

---

## 📄 License

MIT
