import { PrismaClient } from '@prisma/client'
import { config } from '../src/config/index'

export const prisma = new PrismaClient()

export async function setupTestDb() {
  await prisma.$connect()
}

export async function teardownTestDb() {
  await prisma.$disconnect()
}

export async function cleanDb() {
  // Delete in reverse dependency order
  await prisma.booking.deleteMany()
  await prisma.diningReservation.deleteMany()
  await prisma.contactMessage.deleteMany()
  await prisma.review.deleteMany()
  await prisma.adminSession.deleteMany()
  await prisma.adminUser.deleteMany()
  await prisma.roomInventory.deleteMany()
  await prisma.room.deleteMany()
  await prisma.offer.deleteMany()
  await prisma.galleryImage.deleteMany()
  await prisma.hotelSetting.deleteMany()
}