import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest'
import { prisma, setupTestDb, teardownTestDb, cleanDb } from './setup'
import { config } from '../src/config/index'
import bcrypt from 'bcryptjs'

const BASE = `http://localhost:${config.port}`
let server: any
let cookie: string | null = null

function req(method: string, path: string, body?: any, authCookie?: string) {
  return new Promise<{ status: number; body: any }>((resolve, reject) => {
    const { URL } = require('url')
    const url = new URL(BASE + path)
    const options: any = {
      hostname: url.hostname,
      port: url.port,
      path: url.pathname + url.search,
      method,
      headers: {} as any,
    }
    if (body) options.headers['Content-Type'] = 'application/json'
    if (authCookie) options.headers.Cookie = authCookie

    const r = require('http').request(options, (res: any) => {
      let d = ''
      res.on('data', (c: string) => (d += c))
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, body: d ? JSON.parse(d) : d })
        } catch {
          resolve({ status: res.statusCode, body: d })
        }
      })
    })
    r.on('error', reject)
    if (body) r.write(JSON.stringify(body))
    r.end()
  })
}

beforeAll(async () => {
  await setupTestDb()
  // Start server programmatically
  const { start } = require('../src/index')
  // Note: index.ts starts listening on import, so we just wait
  await new Promise((r) => setTimeout(r, 2000))
})

afterAll(async () => {
  await teardownTestDb()
})

beforeEach(async () => {
  await cleanDb()
  // Seed admin
  const passwordHash = await bcrypt.hash('testpass123', 12)
  await prisma.adminUser.create({
    data: { email: 'admin@test.example', passwordHash, role: 'SUPER_ADMIN' },
  })
})

describe('Rooms API', () => {
  it('GET /api/v1/rooms - list rooms', async () => {
    await prisma.room.create({
      data: {
        name: 'Test Room',
        type: 'Deluxe',
        description: 'Test',
        capacity: 2,
        basePrice: 1000,
        images: '[]',
        amenities: '[]',
      },
    })
    const res = await req('GET', '/api/v1/rooms')
    expect(res.status).toBe(200)
    expect(res.body.rooms.length).toBeGreaterThan(0)
  })

  it('GET /api/v1/rooms/availability', async () => {
    await prisma.room.create({
      data: {
        name: 'Test Room',
        type: 'Deluxe',
        description: 'Test',
        capacity: 2,
        basePrice: 1000,
        images: '[]',
        amenities: '[]',
        active: true,
      },
    })
    // Create inventory for test dates
    const today = new Date('2026-12-01')
    await prisma.roomInventory.createMany({
      data: Array.from({ length: 5 }, (_, i) => {
        const d = new Date(today)
        d.setDate(d.getDate() + i)
        return {
          roomId: 'temp', // will be fixed below
          date: d,
          totalRooms: 5,
          availableRooms: 5,
        }
      }),
    })
    const res = await req(
      'GET',
      '/api/v1/rooms/availability?checkIn=2026-12-01&checkOut=2026-12-03&guests=2'
    )
    expect(res.status).toBe(200)
  })
})

describe('Booking API', () => {
  it('POST /api/v1/bookings - create booking', async () => {
    // Create a room with inventory
    const room = await prisma.room.create({
      data: {
        name: 'Test Room',
        type: 'Deluxe',
        description: 'Test',
        capacity: 2,
        basePrice: 1000,
        images: '[]',
        amenities: '[]',
        active: true,
      },
    })
    for (let i = 0; i < 3; i++) {
      const d = new Date('2026-12-01')
      d.setDate(d.getDate() + i)
      await prisma.roomInventory.create({
        data: {
          roomId: room.id,
          date: d,
          totalRooms: 5,
          availableRooms: 5,
        },
      })
    }

    const res = await req('POST', '/api/v1/bookings', {
      firstName: 'John',
      lastName: 'Doe',
      email: 'john@test.example',
      phone: '+91 9999999999',
      checkIn: '2026-12-01',
      checkOut: '2026-12-03',
      adults: '2',
      children: '0',
      roomType: 'Deluxe',
      rooms: '1',
      idempotencyKey: 'test-idem-001',
    })
    expect(res.status).toBe(201)
    expect(res.body.booking.reference).toMatch(/^SRH-/)
    expect(res.body.booking.totalAmount).toBeGreaterThan(0)
  })

  it('POST /api/v1/bookings - idempotent duplicate', async () => {
    const room = await prisma.room.create({
      data: {
        name: 'Test Room',
        type: 'Deluxe',
        description: 'Test',
        capacity: 2,
        basePrice: 1000,
        images: '[]',
        amenities: '[]',
        active: true,
      },
    })
    for (let i = 0; i < 3; i++) {
      const d = new Date('2026-12-01')
      d.setDate(d.getDate() + i)
      await prisma.roomInventory.create({
        data: { roomId: room.id, date: d, totalRooms: 5, availableRooms: 5 },
      })
    }

    await req('POST', '/api/v1/bookings', {
      firstName: 'John', lastName: 'Doe', email: 'john@test.example',
      phone: '+91 9999999999', checkIn: '2026-12-01', checkOut: '2026-12-03',
      adults: '2', children: '0', roomType: 'Deluxe', rooms: '1',
      idempotencyKey: 'test-idem-002',
    })
    const res = await req('POST', '/api/v1/bookings', {
      firstName: 'John', lastName: 'Doe', email: 'john@test.example',
      phone: '+91 9999999999', checkIn: '2026-12-01', checkOut: '2026-12-03',
      adults: '2', children: '0', roomType: 'Deluxe', rooms: '1',
      idempotencyKey: 'test-idem-002',
    })
    expect(res.status).toBe(200)
    expect(res.body.isDuplicate).toBe(true)
  })

  it('POST /api/v1/bookings/verify - public lookup', async () => {
    const room = await prisma.room.create({
      data: {
        name: 'Test Room', type: 'Deluxe', description: 'Test',
        capacity: 2, basePrice: 1000, images: '[]', amenities: '[]', active: true,
      },
    })
    for (let i = 0; i < 3; i++) {
      const d = new Date('2026-12-01')
      d.setDate(d.getDate() + i)
      await prisma.roomInventory.create({
        data: { roomId: room.id, date: d, totalRooms: 5, availableRooms: 5 },
      })
    }

    const createRes = await req('POST', '/api/v1/bookings', {
      firstName: 'John', lastName: 'Doe', email: 'john@test.example',
      phone: '+91 9999999999', checkIn: '2026-12-01', checkOut: '2026-12-03',
      adults: '2', children: '0', roomType: 'Deluxe', rooms: '1',
      idempotencyKey: 'test-idem-003',
    })
    const ref = createRes.body.booking.reference

    const verifyRes = await req('POST', '/api/v1/bookings/verify', {
      reference: ref,
      email: 'john@test.example',
    })
    expect(verifyRes.status).toBe(200)
    expect(verifyRes.body.booking.reference).toBe(ref)

    // Wrong email should fail
    const wrongRes = await req('POST', '/api/v1/bookings/verify', {
      reference: ref,
      email: 'wrong@test.example',
    })
    expect(wrongRes.status).toBe(404)
  })

  it('POST /api/v1/bookings/:reference/cancel', async () => {
    const room = await prisma.room.create({
      data: {
        name: 'Test Room', type: 'Deluxe', description: 'Test',
        capacity: 2, basePrice: 1000, images: '[]', amenities: '[]', active: true,
      },
    })
    for (let i = 0; i < 3; i++) {
      const d = new Date('2026-12-01')
      d.setDate(d.getDate() + i)
      await prisma.roomInventory.create({
        data: { roomId: room.id, date: d, totalRooms: 5, availableRooms: 5 },
      })
    }

    const createRes = await req('POST', '/api/v1/bookings', {
      firstName: 'John', lastName: 'Doe', email: 'john@test.example',
      phone: '+91 9999999999', checkIn: '2026-12-01', checkOut: '2026-12-03',
      adults: '2', children: '0', roomType: 'Deluxe', rooms: '1',
      idempotencyKey: 'test-idem-004',
    })
    const ref = createRes.body.booking.reference

    const cancelRes = await req('POST', `/api/v1/bookings/${ref}/cancel`, {
      email: 'john@test.example',
      reason: 'Test cancel',
    })
    expect(cancelRes.status).toBe(200)
    expect(cancelRes.body.booking.status).toBe('CANCELLED')
  })
})

describe('Dining API', () => {
  it('POST /api/v1/dining-reservations', async () => {
    const res = await req('POST', '/api/v1/dining-reservations', {
      name: 'Jane', email: 'jane@test.example', phone: '+91 8888888888',
      date: '2026-12-25', time: '19:30', guests: '4', occasion: 'Test',
    })
    expect(res.status).toBe(201)
    expect(res.body.reservation.status).toBe('PENDING')
  })
})

describe('Contact API', () => {
  it('POST /api/v1/contact', async () => {
    const res = await req('POST', '/api/v1/contact', {
      name: 'Test', email: 'test@test.example', subject: 'Hello', message: 'Test message',
    })
    expect(res.status).toBe(201)
    expect(res.body.contact.status).toBe('NEW')
  })
})

describe('Reviews API', () => {
  it('GET /api/v1/reviews - only approved', async () => {
    await prisma.review.create({
      data: { name: 'A', rating: 5, comment: 'Good', approved: true },
    })
    await prisma.review.create({
      data: { name: 'B', rating: 1, comment: 'Bad', approved: false },
    })
    const res = await req('GET', '/api/v1/reviews')
    expect(res.status).toBe(200)
    expect(res.body.reviews.length).toBe(1)
    expect(res.body.reviews[0].approved).toBe(true)
  })

  it('POST /api/v1/reviews - creates unapproved', async () => {
    const res = await req('POST', '/api/v1/reviews', {
      name: 'Reviewer', rating: '5', comment: 'Great!', location: 'Test',
    })
    expect(res.status).toBe(201)
    expect(res.body.review.approved).toBe(false)
  })
})

describe('Offers API', () => {
  it('GET /api/v1/offers', async () => {
    await prisma.offer.create({
      data: { title: 'Test Offer', discount: '10% OFF', active: true },
    })
    const res = await req('GET', '/api/v1/offers')
    expect(res.status).toBe(200)
    expect(res.body.offers.length).toBeGreaterThan(0)
  })
})

describe('Admin Auth', () => {
  it('POST /api/v1/admin/auth/login', async () => {
    const res = await req('POST', '/api/v1/admin/auth/login', {
      email: 'admin@test.example',
      password: 'testpass123',
    })
    expect(res.status).toBe(200)
    cookie = res.headers['set-cookie'][0]
    expect(cookie).toBeDefined()
  })

  it('GET /api/v1/admin/auth/me - with auth', async () => {
    // Login first
    await req('POST', '/api/v1/admin/auth/login', {
      email: 'admin@test.example',
      password: 'testpass123',
    })
    cookie = (await req('POST', '/api/v1/admin/auth/login', {
      email: 'admin@test.example',
      password: 'testpass123',
    })).headers['set-cookie'][0]

    const res = await req('GET', '/api/v1/admin/auth/me', null, cookie)
    expect(res.status).toBe(200)
    expect(res.body.admin.email).toBe('admin@test.example')
  })

  it('GET /api/v1/admin/auth/me - without auth', async () => {
    const res = await req('GET', '/api/v1/admin/auth/me')
    expect(res.status).toBe(401)
  })

  it('POST /api/v1/admin/auth/logout', async () => {
    await req('POST', '/api/v1/admin/auth/login', {
      email: 'admin@test.example',
      password: 'testpass123',
    })
    cookie = (await req('POST', '/api/v1/admin/auth/login', {
      email: 'admin@test.example',
      password: 'testpass123',
    })).headers['set-cookie'][0]

    const res = await req('POST', '/api/v1/admin/auth/logout', null, cookie)
    expect(res.status).toBe(200)

    const meRes = await req('GET', '/api/v1/admin/auth/me', null, cookie)
    expect(meRes.status).toBe(401)
  })
})

describe('Admin RBAC', () => {
  it('Admin routes reject unauthenticated requests', async () => {
    const res = await req('GET', '/api/v1/admin/dashboard/stats')
    expect(res.status).toBe(401)
  })

  it('Admin routes reject wrong password', async () => {
    const res = await req('POST', '/api/v1/admin/auth/login', {
      email: 'admin@test.example',
      password: 'wrongpassword',
    })
    expect(res.status).toBe(401)
  })
})