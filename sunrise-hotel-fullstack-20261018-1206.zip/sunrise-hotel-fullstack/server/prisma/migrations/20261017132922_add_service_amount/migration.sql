-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Booking" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "reference" TEXT NOT NULL,
    "roomId" TEXT,
    "guestId" TEXT,
    "firstName" TEXT NOT NULL,
    "lastName" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "phone" TEXT NOT NULL,
    "checkIn" DATETIME NOT NULL,
    "checkOut" DATETIME NOT NULL,
    "adults" INTEGER NOT NULL,
    "children" INTEGER NOT NULL DEFAULT 0,
    "rooms" INTEGER NOT NULL DEFAULT 1,
    "roomType" TEXT NOT NULL,
    "baseAmount" REAL NOT NULL,
    "taxAmount" REAL NOT NULL DEFAULT 0,
    "serviceAmount" REAL NOT NULL DEFAULT 0,
    "discountAmount" REAL NOT NULL DEFAULT 0,
    "totalAmount" REAL NOT NULL,
    "currency" TEXT NOT NULL DEFAULT 'INR',
    "status" TEXT NOT NULL DEFAULT 'PENDING',
    "paymentStatus" TEXT NOT NULL DEFAULT 'UNPAID',
    "specialRequest" TEXT,
    "cancellationReason" TEXT,
    "cancelledAt" DATETIME,
    "idempotencyKey" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "Booking_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES "Room" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "Booking_guestId_fkey" FOREIGN KEY ("guestId") REFERENCES "Guest" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);
INSERT INTO "new_Booking" ("adults", "baseAmount", "cancellationReason", "cancelledAt", "checkIn", "checkOut", "children", "createdAt", "currency", "discountAmount", "email", "firstName", "guestId", "id", "idempotencyKey", "lastName", "paymentStatus", "phone", "reference", "roomId", "roomType", "rooms", "specialRequest", "status", "taxAmount", "totalAmount", "updatedAt") SELECT "adults", "baseAmount", "cancellationReason", "cancelledAt", "checkIn", "checkOut", "children", "createdAt", "currency", "discountAmount", "email", "firstName", "guestId", "id", "idempotencyKey", "lastName", "paymentStatus", "phone", "reference", "roomId", "roomType", "rooms", "specialRequest", "status", "taxAmount", "totalAmount", "updatedAt" FROM "Booking";
DROP TABLE "Booking";
ALTER TABLE "new_Booking" RENAME TO "Booking";
CREATE UNIQUE INDEX "Booking_id_key" ON "Booking"("id");
CREATE UNIQUE INDEX "Booking_reference_key" ON "Booking"("reference");
CREATE INDEX "Booking_reference_idx" ON "Booking"("reference");
CREATE INDEX "Booking_email_idx" ON "Booking"("email");
CREATE INDEX "Booking_status_idx" ON "Booking"("status");
CREATE INDEX "Booking_checkIn_checkOut_idx" ON "Booking"("checkIn", "checkOut");
CREATE INDEX "Booking_idempotencyKey_idx" ON "Booking"("idempotencyKey");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
