import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'
import { config } from '../src/config/index'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Seeding demo data...')

  // 1. Hotel settings
  await prisma.hotelSetting.upsert({
    where: { id: 'demo-setting-1' },
    update: {},
    create: {
      id: 'demo-setting-1',
      hotelName: 'Sunrise Hotels & Resorts',
      contactEmail: 'info@sunrisehotel.example',
      contactPhone: '+91 90004 84626',
      address: 'Beach Road, Coastal City',
      checkInTime: '15:00',
      checkOutTime: '11:00',
      currency: 'INR',
      taxRate: 12,
      serviceChargeRate: 5,
      cancellationPolicy:
        'Free cancellation up to 24 hours before check-in. 50% charge within 24 hours.',
    },
  })

  // 2. Admin user
  const adminEmail = config.adminEmail || 'admin@sunrisehotel.example'
  const adminPassword = config.adminPassword || 'change-me-in-production'

  const existingAdmin = await prisma.adminUser.findUnique({ where: { email: adminEmail } })
  if (!existingAdmin) {
    const passwordHash = await bcrypt.hash(adminPassword, 12)
    await prisma.adminUser.create({
      data: {
        email: adminEmail,
        passwordHash,
        role: 'SUPER_ADMIN',
        isActive: true,
      },
    })
    console.log(`✅ Admin user created: ${adminEmail}`)
  } else {
    console.log(`⚠️  Admin user already exists: ${adminEmail}`)
  }

  // 3. Rooms (demo data)
  const rooms = [
    {
      name: 'Deluxe Room',
      type: 'Deluxe',
      description: 'Comfortable room with city view, king-size bed, and modern amenities.',
      capacity: 2,
      basePrice: 2500,
      currency: 'INR',
      size: '250 sq ft',
      beds: '1 King',
      view: 'City',
      images: JSON.stringify([
        'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?w=800',
      ]),
      amenities: JSON.stringify(['Wi-Fi', 'AC', 'TV', 'Mini Bar', 'Room Service']),
      active: true,
    },
    {
      name: 'Luxury Room',
      type: 'Luxury',
      description: 'Spacious luxury room with sea view, premium bedding, and balcony.',
      capacity: 2,
      basePrice: 4000,
      currency: 'INR',
      size: '350 sq ft',
      beds: '1 King',
      view: 'Sea',
      images: JSON.stringify([
        'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800',
      ]),
      amenities: JSON.stringify([
        'Wi-Fi', 'AC', 'TV', 'Mini Bar', 'Room Service', 'Balcony', 'Sea View',
      ]),
      active: true,
    },
    {
      name: 'Family Room',
      type: 'Family',
      description: 'Large family room with two queen beds, ideal for families with children.',
      capacity: 4,
      basePrice: 5000,
      currency: 'INR',
      size: '450 sq ft',
      beds: '2 Queen',
      view: 'Garden',
      images: JSON.stringify([
        'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?w=800',
      ]),
      amenities: JSON.stringify([
        'Wi-Fi', 'AC', 'TV', 'Mini Bar', 'Room Service', 'Kids Friendly',
      ]),
      active: true,
    },
    {
      name: 'Presidential Suite',
      type: 'Suite',
      description: 'Ultra-luxury suite with ocean view, private butler, and jacuzzi.',
      capacity: 2,
      basePrice: 12000,
      currency: 'INR',
      size: '700 sq ft',
      beds: '1 King',
      view: 'Ocean',
      images: JSON.stringify([
        'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800',
      ]),
      amenities: JSON.stringify([
        'Wi-Fi', 'AC', 'TV', 'Mini Bar', 'Room Service', 'Butler', 'Jacuzzi', 'Ocean View',
      ]),
      active: true,
    },
  ]

  for (const roomData of rooms) {
    const room = await prisma.room.create({
      data: roomData,
    })

    // Create inventory records for the next 90 days
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    for (let i = 0; i < 90; i++) {
      const date = new Date(today)
      date.setDate(date.getDate() + i)
      await prisma.roomInventory.create({
        data: {
          roomId: room.id,
          date,
          totalRooms: roomData.capacity,
          availableRooms: roomData.capacity,
        },
      })
    }
  }

  console.log(`✅ ${rooms.length} rooms created with inventory`)

  // 4. Offers (demo data)
  const now = new Date()
  const future = new Date(now)
  future.setMonth(future.getMonth() + 6)

  const offers = [
    {
      title: 'Weekend Escape',
      subtitle: 'Fri–Sun stays',
      discount: '20% OFF',
      description: 'Enjoy a relaxing weekend with free breakfast.',
      validFrom: now,
      validTill: future,
      active: true,
    },
    {
      title: 'Romance Package',
      subtitle: 'Honeymoon Special',
      discount: '15% OFF',
      description: 'Candlelight dinner, flowers & spa for two.',
      validFrom: now,
      validTill: future,
      active: true,
    },
    {
      title: 'Celebrate Big',
      subtitle: 'Festival Season',
      discount: 'Up to 30% OFF',
      description: 'Special festival discounts on all room types.',
      validFrom: now,
      validTill: future,
      active: true,
    },
    {
      title: 'Business Plan',
      subtitle: 'Corporate Stays',
      discount: '10% OFF',
      description: 'Meeting hall, Wi-Fi & discounted rates for business travelers.',
      validFrom: now,
      validTill: future,
      active: true,
    },
  ]

  for (const offer of offers) {
    await prisma.offer.create({ data: offer })
  }
  console.log(`✅ ${offers.length} offers created`)

  // 5. Gallery images
  const gallery = [
    { title: 'Lobby', category: 'property', url: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800', active: true },
    { title: 'Deluxe Room', category: 'rooms', url: 'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?w=800', active: true },
    { title: 'Pool', category: 'amenities', url: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800', active: true },
    { title: 'Restaurant', category: 'dining', url: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800', active: true },
  ]

  for (const g of gallery) {
    await prisma.galleryImage.create({ data: g })
  }
  console.log(`✅ ${gallery.length} gallery images created`)

  // 6. Demo reviews (unapproved - need moderation)
  const reviews = [
    { name: 'Priya S.', rating: 5, comment: 'Stunning sea view and the friendliest staff. Breakfast buffet was superb!', location: 'Goa', approved: true },
    { name: 'Rahul M.', rating: 5, comment: 'Perfect for our family vacation. Kids loved the pool and the rooms were spotless.', location: 'Mumbai', approved: true },
    { name: 'Daniel K.', rating: 4, comment: 'Great business facilities and fast Wi-Fi. Airport pickup was seamless.', location: 'Delhi', approved: true },
    { name: 'Anita R.', rating: 5, comment: 'Loved the Presidential Suite. The ocean view was breathtaking.', location: 'Bangalore', approved: false },
  ]

  for (const r of reviews) {
    await prisma.review.create({ data: r })
  }
  console.log(`✅ ${reviews.length} reviews created`)

  console.log('✅ Seed complete!')
  console.log(`🔑 Admin credentials: ${adminEmail} / ${adminPassword}`)
  console.log('⚠️  DEMO DATA ONLY - Change credentials before production!')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })