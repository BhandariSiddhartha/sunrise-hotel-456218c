const ROOMS = [
  { id: 0, n: "Deluxe Room", p: 3500, bed: "Queen", size: "28 m²", icon: "🛏️", image: "https://images.unsplash.com/photo-1611892440504-42a792e24d32?auto=format&fit=crop&w=1000&q=85" },
  { id: 1, n: "Premium Sea View", p: 5200, bed: "King", size: "36 m²", icon: "🌅", image: "https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=1000&q=85" },
  { id: 2, n: "Family Suite", p: 7500, bed: "2 Queen", size: "55 m²", icon: "👨‍👩‍👧", image: "https://images.unsplash.com/photo-1566665797739-1674de7a421a?auto=format&fit=crop&w=1000&q=85" },
  { id: 3, n: "Royal Presidential Suite", p: 14000, bed: "King + Lounge", size: "90 m²", icon: "👑", image: "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1000&q=85" }
];

const ROOM_TYPES = ["Deluxe", "Luxury", "Family", "Suite"];
const $ = selector => document.querySelector(selector);
const fmt = amount => "₹" + amount.toLocaleString("en-IN");
const API_BASE = "/api/v1";
async function apiRequest(path, options = {}) {
  let response;
  try {
    response = await fetch(`${API_BASE}${path}`, {
      credentials: "same-origin",
      headers: { "Content-Type": "application/json", ...options.headers },
      ...options
    });
  } catch {
    throw new Error("Could not reach the hotel API. Start the full-stack app with npm run dev.");
  }
  const isJSON = response.headers.get("content-type")?.includes("application/json");
  const result = isJSON ? await response.json().catch(() => ({})) : {};
  if (!isJSON && !response.ok) {
    throw new Error(`The hotel API is unavailable (HTTP ${response.status}). Start the full-stack app with npm run dev.`);
  }
  if (!response.ok) throw new Error(result.error || result.message || "The request could not be completed.");
  return result;
}
const iso = date => {
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 10);
};
const escapeHTML = value => String(value).replace(/[&<>"']/g, char => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
}[char]));

const today = new Date();
const tomorrow = new Date();
tomorrow.setDate(tomorrow.getDate() + 1);
const dayAfter = new Date();
dayAfter.setDate(dayAfter.getDate() + 2);
$("#ci").min = iso(today);
$("#ci").value = iso(today);
$("#co").min = iso(tomorrow);
$("#co").value = iso(dayAfter);

$("#rt").innerHTML = ROOMS.map(room => `<option value="${room.id}">${room.n}</option>`).join("");
$("#roomGrid").innerHTML = ROOMS.map(room => `
  <article class="card">
    <div class="pic" style="background-image:linear-gradient(180deg,transparent 45%,rgba(5,14,12,.38)),url(&quot;${room.image}&quot;)" role="img" aria-label="${room.n} room photo"><span>${room.icon}</span></div>
    <div class="pad">
      <h3>${room.n}</h3>
      <div class="price" data-room-price="${room.id}">${fmt(room.p)} <small>/ night</small></div>
      <p style="color:var(--mute);font-size:.88rem">🛏️ ${room.bed} bed · 📐 ${room.size}</p>
      <div class="tags"><span>Wi-Fi</span><span>AC</span><span>Smart TV</span><span>Bathtub &amp; Shower</span><span>Room Service</span></div>
      <button class="btn" type="button" data-book="${room.id}">Book This Room</button>
    </div>
  </article>`).join("");

async function updateRoomPrices() {
  const { rooms } = await apiRequest("/rooms");
  ROOMS.forEach(room => {
    const liveRoom = rooms.find(item => item.type === ROOM_TYPES[room.id]);
    if (!liveRoom) return;
    room.p = liveRoom.basePrice;
    room.bed = liveRoom.beds || room.bed;
    room.size = liveRoom.size || room.size;
    const priceElement = document.querySelector(`[data-room-price="${room.id}"]`);
    if (priceElement) priceElement.innerHTML = `${fmt(room.p)} <small>/ night</small>`;
  });
}

const AMENITIES = [
  { name: "Swimming Pool", image: "pool.jpg", description: "Take a refreshing break at the hotel's swimming pool." },
  { name: "Restaurant", image: "restaurant.jpg", description: "Enjoy Indian and international dishes at the Sunrise restaurant." },
  { name: "Gym", image: "gym.jpg", description: "Keep up your workout routine in the hotel's fitness room." },
  { name: "Spa", image: "spa.jpg", description: "Unwind with a relaxing spa experience during your stay." },
  { name: "Conference Hall", image: "conference.jpg", description: "Host meetings and events with the hotel's conference facilities." },
  { name: "Free Parking", image: "parking.jpg", description: "Complimentary parking is available for hotel guests." },
  { name: "Airport Pickup", image: "airport-pickup.jpg", description: "Ask the hotel team to arrange an airport pickup for your stay." },
  { name: "Laundry", image: "laundry.jpg", description: "Laundry assistance is available during your stay." },
  { name: "24/7 Reception", image: "reception.jpg", description: "The reception team is available around the clock to assist you." }
];
$("#amGrid").innerHTML = AMENITIES.map((amenity, index) => `
  <button class="card am amenity-card" type="button" data-amenity="${index}" aria-haspopup="dialog">
    <img src="/images/amenities/${amenity.image}" alt="" loading="lazy">
    <div>${amenity.name}</div>
  </button>`).join("");

const MENU = {
  Starters: [["Paneer Tikka", "Charred cottage cheese, mint chutney", 320], ["Prawn Koliwada", "Crispy spiced prawns", 480]],
  Mains: [["Hyderabadi Biryani", "Chef's special, slow-cooked dum style", 420], ["Butter Chicken", "Creamy tomato gravy with naan", 450], ["Veg Thali", "Seasonal curries, dal, rice, bread", 380]],
  Desserts: [["Gulab Jamun", "Warm with rabri", 180], ["Sunrise Sundae", "Mango, vanilla & saffron", 220]]
};
$("#tabs").innerHTML = Object.keys(MENU).map((category, index) =>
  `<button type="button" class="${index === 0 ? "on" : ""}" data-category="${category}">${category}</button>`
).join("");
function showMenu(category) {
  $("#menu").innerHTML = MENU[category].map(dish =>
    `<div class="dish"><div><b>${dish[0]}</b><small>${dish[1]}</small></div><b>${fmt(dish[2])}</b></div>`
  ).join("");
}
showMenu("Starters");
$("#tabs").addEventListener("click", event => {
  const category = event.target.dataset.category;
  if (!category) return;
  $("#tabs").querySelectorAll("button").forEach(button => button.classList.toggle("on", button === event.target));
  showMenu(category);
});

$("#galGrid").innerHTML = [
  ["Exterior", "#ff9a3d,#b4411f"], ["Lobby", "#d4a95a,#6b4423"],
  ["Rooms", "#5aa9d4,#1f4f7a"], ["Restaurant", "#d45a6b,#7a1f3a"],
  ["Events", "#9b6fd4,#3f1f7a"], ["Nearby Beach", "#4ad4b8,#1f7a6b"],
  ["Pool", "#4ab0e8,#1b6aa5"], ["Old Fort", "#c9a27a,#6b4a2a"]
].map(item => `<div style="background:linear-gradient(135deg,${item[1]})">${item[0]}</div>`).join("");

function nights(checkIn = $("#ci").value, checkOut = $("#co").value) {
  return Math.round((new Date(checkOut) - new Date(checkIn)) / 86400000);
}
$("#ci").addEventListener("change", () => {
  const nextDay = new Date(`${$("#ci").value}T00:00:00`);
  nextDay.setDate(nextDay.getDate() + 1);
  $("#co").min = iso(nextDay);
  if ($("#co").value <= $("#ci").value) $("#co").value = iso(nextDay);
});
$("#chk").addEventListener("click", async () => {
  const count = nights();
  if (count <= 0) {
    $("#avail").textContent = "Please choose valid dates.";
    return;
  }
  const room = ROOMS[Number($("#rt").value)];
  $("#avail").textContent = "Checking live availability…";
  try {
    const query = new URLSearchParams({ checkIn: $("#ci").value, checkOut: $("#co").value, guests: String(Number.parseInt($("#gu").value, 10) || 1), roomType: ROOM_TYPES[room.id] });
    const result = await apiRequest(`/rooms/availability?${query}`);
    const available = result.rooms.find(item => item.type === ROOM_TYPES[room.id]);
    $("#avail").textContent = available
      ? `${available.availableRooms} ${room.n} room(s) available · ${result.nights} night(s) · ${fmt(available.priceBreakdown.totalAmount)} total including taxes and service. `
      : `No ${room.n} rooms are available for those dates. Try different dates.`;
    if (available) {
      const link = document.createElement("a");
      link.href = "#";
      link.id = "availabilityBook";
      link.style.color = "#fff";
      link.textContent = "Continue →";
      $("#avail").append(link);
    }
  } catch (error) {
    $("#avail").textContent = `Could not check availability: ${error.message}`;
  }
  const bookLink = $("#availabilityBook");
  if (bookLink) bookLink.addEventListener("click", event => {
    event.preventDefault();
    openBook(room.id);
  });
});

const modal = $("#modal");
const modalBox = $("#mbox");
function closeModal() {
  modal.classList.remove("show");
}
function openAmenity(amenityIndex) {
  const amenity = AMENITIES[amenityIndex];
  if (!amenity) return;
  modalBox.innerHTML = `
    <button class="x" type="button" aria-label="Close" data-close>×</button>
    <h3>${escapeHTML(amenity.name)}</h3>
    <p>${escapeHTML(amenity.description)}</p>
    <a class="btn" href="#contact" data-close>Contact the hotel</a>`;
  modal.classList.add("show");
}
function openBook(roomId) {
  const room = ROOMS[roomId];
  modalBox.innerHTML = `
    <button class="x" type="button" aria-label="Close" data-close>×</button>
    <h3>Book ${room.n}</h3>
    <form id="bookingForm">
      <div class="row"><div><label for="bookIn">Check-in</label><input type="date" id="bookIn" value="${$("#ci").value}" min="${iso(today)}" required></div>
      <div><label for="bookOut">Check-out</label><input type="date" id="bookOut" value="${$("#co").value}" required></div></div>
      <div class="row"><div><label for="bookName">Full name</label><input id="bookName" required></div>
      <div><label for="bookPhone">Phone</label><input id="bookPhone" type="tel" required></div></div>
      <div style="margin-bottom:10px"><label for="bookEmail">Email</label><input type="email" id="bookEmail" required></div>
      <p class="price">The hotel server will calculate your total when you submit.</p>
      <p class="pol">Cancellation policy: free cancellation up to 48 hours before check-in. Later cancellations are charged one night.</p>
      <button class="btn" type="submit" style="width:100%">Request Booking</button>
    </form>`;
  modal.classList.add("show");

  const checkIn = $("#bookIn");
  const checkOut = $("#bookOut");
  checkIn.addEventListener("change", () => {
    const nextDay = new Date(`${checkIn.value}T00:00:00`);
    nextDay.setDate(nextDay.getDate() + 1);
    checkOut.min = iso(nextDay);
    if (checkOut.value <= checkIn.value) checkOut.value = iso(nextDay);
  });

  $("#bookingForm").addEventListener("submit", async event => {
    event.preventDefault();
    const count = nights(checkIn.value, checkOut.value);
    if (count <= 0) {
      alert("Check-out must be after check-in.");
      return;
    }
    const fullName = $("#bookName").value.trim().split(/\s+/);
    const submitButton = event.submitter;
    submitButton.disabled = true;
    try {
      const result = await apiRequest("/bookings", {
        method: "POST",
        body: JSON.stringify({
          firstName: fullName.shift(),
          lastName: fullName.join(" ") || "Guest",
          email: $("#bookEmail").value.trim(),
          phone: $("#bookPhone").value.trim(),
          checkIn: checkIn.value,
          checkOut: checkOut.value,
          adults: Number.parseInt($("#gu").value, 10) || 1,
          children: 0,
          roomType: ROOM_TYPES[room.id],
          rooms: 1,
          idempotencyKey: crypto.randomUUID()
        })
      });
      const booking = result.booking;
      const guestName = escapeHTML(`${booking.firstName} ${booking.lastName}`);
      const reference = escapeHTML(booking.reference);
      modalBox.innerHTML = `<button class="x" type="button" aria-label="Close" data-close>×</button>
        <h3>✅ Booking Request Received</h3><p>Thank you, <b>${guestName}</b>.</p>
        <p style="margin:10px 0">Reference: <b>${reference}</b><br>${room.n} · ${count} night(s)<br>${checkIn.value} → ${checkOut.value}<br>Total: ${fmt(booking.totalAmount)}</p>
        <p class="pol">Your request is saved with the hotel. Payment is not enabled in this setup; the hotel will confirm your booking.</p>
        <button class="btn" type="button" data-close>Done</button>`;
    } catch (error) {
      alert(`Booking could not be submitted: ${error.message}`);
      submitButton.disabled = false;
    }
  });
}

document.addEventListener("click", event => {
  const amenityButton = event.target.closest("[data-amenity]");
  if (amenityButton) openAmenity(Number(amenityButton.dataset.amenity));
  const bookButton = event.target.closest("[data-book]");
  if (bookButton) openBook(Number(bookButton.dataset.book));
  if (event.target.closest("[data-close]") || event.target === modal) closeModal();
});
$("#tbl").addEventListener("click", () => {
  modalBox.innerHTML = `<button class="x" type="button" aria-label="Close" data-close>×</button>
    <h3>Reserve a Table</h3><form id="tableForm">
      <div class="row"><div><label for="tableDate">Date</label><input id="tableDate" type="date" min="${iso(today)}" required></div>
      <div><label for="tableTime">Time</label><input id="tableTime" type="time" value="20:00" required></div></div>
      <div class="row"><div><label for="tableName">Name</label><input id="tableName" required></div>
      <div><label for="tableGuests">Guests</label><input id="tableGuests" type="number" min="1" value="2" required></div></div>
      <div class="row"><div><label for="tableEmail">Email</label><input id="tableEmail" type="email" required></div>
      <div><label for="tablePhone">Phone</label><input id="tablePhone" type="tel" required></div></div>
      <button class="btn" type="submit" style="width:100%">Reserve</button></form>`;
  modal.classList.add("show");
  $("#tableForm").addEventListener("submit", async event => {
    event.preventDefault();
    const submitButton = event.submitter;
    submitButton.disabled = true;
    try {
      const result = await apiRequest("/dining-reservations", {
        method: "POST",
        body: JSON.stringify({
          name: $("#tableName").value.trim(),
          email: $("#tableEmail").value.trim(),
          phone: $("#tablePhone").value.trim(),
          date: $("#tableDate").value,
          time: $("#tableTime").value,
          guests: Number($("#tableGuests").value)
        })
      });
      modalBox.innerHTML = `<button class="x" type="button" aria-label="Close" data-close>×</button><h3>✅ Reservation Request Sent</h3><p>${escapeHTML(result.message)}</p>`;
    } catch (error) {
      alert(`Reservation could not be submitted: ${error.message}`);
      submitButton.disabled = false;
    }
  });
});

document.querySelectorAll("[data-pol]").forEach(link => link.addEventListener("click", () => {
  const policy = link.dataset.pol;
  modalBox.innerHTML = `<button class="x" type="button" aria-label="Close" data-close>×</button>
    <h3>${escapeHTML(policy)}</h3><p style="color:var(--mute)">Sample policy text. Replace with your hotel's official ${escapeHTML(policy.toLowerCase())}.</p>`;
  modal.classList.add("show");
}));
$("#cf").addEventListener("submit", async event => {
  event.preventDefault();
  const form = event.target;
  const submitButton = form.querySelector("button[type='submit'], button:not([type])");
  submitButton.disabled = true;
  $("#cfm").textContent = "Sending…";
  try {
    const result = await apiRequest("/contact", {
      method: "POST",
      body: JSON.stringify({
        name: $("#contactName").value.trim(),
        email: $("#contactEmail").value.trim(),
        message: $("#contactMessage").value.trim()
      })
    });
    $("#cfm").textContent = `✅ ${result.message}`;
    form.reset();
  } catch (error) {
    $("#cfm").textContent = `Could not send message: ${error.message}`;
  } finally {
    submitButton.disabled = false;
  }
});

$("#menuBtn").addEventListener("click", () => $("#links").classList.toggle("open"));
$("#links").addEventListener("click", event => {
  if (event.target.closest("a")) $("#links").classList.remove("open");
});
$("#theme").addEventListener("click", event => {
  event.preventDefault();
  const root = document.documentElement;
  const dark = root.dataset.theme
    ? root.dataset.theme === "dark"
    : window.matchMedia("(prefers-color-scheme: dark)").matches;
  root.dataset.theme = dark ? "light" : "dark";
});

const translations = {
  hi: { nHome: "होम", nAbout: "हमारे बारे में", nRooms: "कमरे", nContact: "संपर्क", title: "सनराइज होटल्स एंड रिसॉर्ट्स", tag: "हर सुबह, एक नई शुरुआत।", book: "अभी बुक करें" },
  te: { nHome: "హోమ్", nAbout: "మా గురించి", nRooms: "గదులు", nContact: "సంప్రదించండి", title: "సన్‌రైజ్ హోటల్స్ & రిసార్ట్స్", tag: "ప్రతి ఉదయం ఒక కొత్త ప్రారంభం.", book: "ఇప్పుడే బుక్ చేయండి" }
};
const originalText = {};
document.querySelectorAll("[data-i18n]").forEach(element => {
  originalText[element.dataset.i18n] = element.innerHTML;
});
$("#lang").addEventListener("change", event => {
  const translationsForLanguage = translations[event.target.value] || {};
  document.querySelectorAll("[data-i18n]").forEach(element => {
    const key = element.dataset.i18n;
    element.innerHTML = translationsForLanguage[key] || originalText[key];
  });
});

const addMessage = (text, type) => {
  const message = document.createElement("div");
  message.className = `m ${type}`;
  message.textContent = text;
  $("#msgs").append(message);
  $("#msgs").scrollTop = $("#msgs").scrollHeight;
};
addMessage("Hi! 👋 I'm the Sunrise assistant. Ask me about rooms, prices, food, check-in or location.", "b");
$("#chatBtn").addEventListener("click", () => $("#chat").classList.toggle("show"));
const answers = [
  [/price|cost|rate|tariff/i, "Rooms start at ₹3,500/night (Deluxe) up to ₹14,000 (Presidential Suite)."],
  [/check.?in|check.?out|time/i, "Check-in is 2 PM and check-out is 11 AM."],
  [/food|restaurant|menu|dinner|breakfast/i, "Breakfast is 7–10, lunch 12–3, and dinner 7–11. Try the Hyderabadi Biryani!"],
  [/pool|gym|spa|wifi|parking/i, "We have a pool, gym, spa, free Wi-Fi and free parking."],
  [/airport|location|where|address|station/i, "We're on Beach Road, 18 km from the airport and 6 km from the railway station."],
  [/cancel|refund/i, "Free cancellation is available up to 48 hours before check-in."],
  [/offer|discount|honeymoon/i, "See our Offers section for Weekend, Honeymoon and Corporate packages."],
  [/book|reserve|room/i, "Use the booking form at the top, or tap 'Book This Room' on any room."]
];
$("#cform").addEventListener("submit", async event => {
  event.preventDefault();
  const question = $("#cin").value.trim();
  if (!question) return;
  addMessage(question, "u");
  $("#cin").value = "";
  try {
    const result = await apiRequest("/chatbot", {
      method: "POST",
      body: JSON.stringify({ question })
    });
    addMessage(result.answer, "b");
  } catch (error) {
    addMessage(`I couldn't reach the hotel assistant: ${error.message}`, "b");
  }
});

// Keyboard accessibility: close overlays with Escape.
document.addEventListener("keydown", event => {
  if (event.key === "Escape") {
    closeModal();
    $("#chat").classList.remove("show");
    $("#links").classList.remove("open");
  }
});

try {
  await updateRoomPrices();
} catch {}
