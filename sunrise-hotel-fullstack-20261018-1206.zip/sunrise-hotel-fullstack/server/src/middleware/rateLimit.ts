import rateLimit from 'express-rate-limit'
import { config } from '../config/index'

// General API rate limit
export const apiRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // 100 requests per window per IP
  message: { error: 'Too many requests, please try again later' },
  standardHeaders: true,
  legacyHeaders: false,
})

// Strict limits for sensitive endpoints
export const authRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10, // 10 login attempts per window
  message: { error: 'Too many login attempts, please try again later' },
  standardHeaders: true,
  legacyHeaders: false,
})

export const bookingRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20, // 20 booking attempts per window
  message: { error: 'Too many booking requests, please try again later' },
  standardHeaders: true,
  legacyHeaders: false,
})

export const contactRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 15, // 15 contact submissions per window
  message: { error: 'Too many contact submissions, please try again later' },
  standardHeaders: true,
  legacyHeaders: false,
})

export const chatbotRateLimit = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 30, // 30 chatbot messages per minute
  message: { error: 'Too many messages, please try again later' },
  standardHeaders: true,
  legacyHeaders: false,
})