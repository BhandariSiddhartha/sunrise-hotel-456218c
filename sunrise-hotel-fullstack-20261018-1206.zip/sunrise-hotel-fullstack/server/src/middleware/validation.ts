import { z } from 'zod'

// Shared schemas
const emailSchema = z.string().email('Invalid email address')
const phoneSchema = z.string().min(5, 'Phone number is required').max(20)
const nameSchema = z.string().min(1, 'Name is required').max(100)
const messageSchema = z.string().min(1, 'Message is required').max(2000)

// Accept both strings and numbers (for JSON API compatibility)
const coerceString = z.preprocess(
  (val) => (typeof val === 'number' ? String(val) : val),
  z.string()
)

// Date validation helpers
const dateStringSchema = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/, 'Date must be in YYYY-MM-DD format')
  .refine((val) => !isNaN(Date.parse(val)), 'Invalid date value')

// Rooms
export const roomQuerySchema = z.object({
  type: z.string().optional(),
  active: z.string().transform((val) => val === 'true').optional().default('true'),
})

export const roomIdParamSchema = z.object({
  id: z.string().cuid('Invalid room ID'),
})

export const roomAvailabilityQuerySchema = z.object({
  checkIn: dateStringSchema,
  checkOut: dateStringSchema,
  guests: coerceString
    .transform((val) => parseInt(val, 10))
    .refine((val) => !isNaN(val) && val > 0, 'Guests must be a positive number')
    .optional()
    .default('1'),
  roomType: z.string().optional(),
})

// Bookings
export const bookingCreateSchema = z.object({
  body: z.object({
    firstName: nameSchema,
    lastName: nameSchema,
    email: emailSchema,
    phone: phoneSchema,
    checkIn: dateStringSchema,
    checkOut: dateStringSchema,
    adults: coerceString
      .transform((val) => parseInt(val, 10))
      .refine((val) => !isNaN(val) && val >= 1, 'Adults must be at least 1'),
    children: coerceString
      .transform((val) => parseInt(val, 10))
      .refine((val) => !isNaN(val) && val >= 0, 'Children must be 0 or more')
      .optional()
      .default('0'),
    roomType: nameSchema,
    rooms: coerceString
      .transform((val) => parseInt(val, 10))
      .refine((val) => !isNaN(val) && val >= 1, 'Rooms must be at least 1')
      .optional()
      .default('1'),
    specialRequest: z.string().max(1000).optional(),
    idempotencyKey: z.string().max(128).optional(),
  }),
})

export const bookingReferenceParamSchema = z.object({
  reference: z.string().min(1, 'Booking reference is required'),
})

export const bookingVerifySchema = z.object({
  body: z.object({
    reference: z.string().min(1),
    email: emailSchema,
  }),
})

export const bookingCancelSchema = z.object({
  params: z.object({
    reference: z.string().min(1),
  }),
  body: z.object({
    email: emailSchema,
    reason: z.string().max(500).optional(),
  }),
})

// Dining
export const diningCreateSchema = z.object({
  body: z.object({
    name: nameSchema,
    email: emailSchema,
    phone: phoneSchema,
    date: dateStringSchema,
    time: z.string().min(1, 'Time is required'),
    guests: coerceString
      .transform((val) => parseInt(val, 10))
      .refine((val) => !isNaN(val) && val >= 1, 'Guests must be at least 1'),
    occasion: z.string().max(100).optional(),
    specialRequest: z.string().max(1000).optional(),
  }),
})

// Contact
export const contactCreateSchema = z.object({
  body: z.object({
    name: nameSchema,
    email: emailSchema,
    subject: z.string().max(200).optional(),
    message: messageSchema,
    phone: phoneSchema.optional(),
  }),
})

// Reviews
export const reviewCreateSchema = z.object({
  body: z.object({
    name: nameSchema,
    rating: coerceString
      .transform((val) => parseInt(val, 10))
      .refine((val) => !isNaN(val) && val >= 1 && val <= 5, 'Rating must be 1-5'),
    comment: z.string().min(1, 'Comment is required').max(2000),
    location: z.string().max(100).optional(),
  }),
})

export const reviewQuerySchema = z.object({
  approved: z.string().transform((val) => val === 'true').optional().default('true'),
})

// Offers
export const offerCreateSchema = z.object({
  body: z.object({
    title: nameSchema,
    subtitle: z.string().max(200).optional(),
    discount: z.string().min(1, 'Discount is required').max(100),
    description: z.string().max(1000).optional(),
    validFrom: dateStringSchema.optional(),
    validTill: dateStringSchema.optional(),
    active: z.string().transform((val) => val === 'true').optional().default('true'),
    image: z.string().url().optional(),
  }),
})

export const offerIdParamSchema = z.object({
  id: z.string().cuid('Invalid offer ID'),
})

// Admin Auth
export const adminLoginSchema = z.object({
  body: z.object({
    email: emailSchema,
    password: z.string().min(6, 'Password must be at least 6 characters'),
  }),
})

// Admin Room
export const adminRoomCreateSchema = z.object({
  body: z.object({
    name: nameSchema,
    type: nameSchema,
    description: z.string().max(2000).optional(),
    capacity: coerceString
      .transform((val) => parseInt(val, 10))
      .refine((val) => !isNaN(val) && val >= 1, 'Capacity must be at least 1'),
    basePrice: coerceString
      .transform((val) => parseFloat(val))
      .refine((val) => !isNaN(val) && val > 0, 'Base price must be greater than 0'),
    currency: z.string().min(1).max(10).optional().default('INR'),
    size: z.string().max(50).optional(),
    beds: z.string().max(50).optional(),
    view: z.string().max(50).optional(),
    images: z.string().optional(),
    amenities: z.string().optional(),
    active: z.string().transform((val) => val === 'true').optional().default('true'),
  }),
})

export const adminRoomUpdateSchema = z.object({
  params: z.object({ id: z.string().cuid() }),
  body: z.object({
    name: nameSchema.optional(),
    type: nameSchema.optional(),
    description: z.string().max(2000).optional(),
    capacity: coerceString
      .transform((val) => parseInt(val, 10))
      .refine((val) => !isNaN(val) && val >= 1, 'Capacity must be at least 1')
      .optional(),
    basePrice: coerceString
      .transform((val) => parseFloat(val))
      .refine((val) => !isNaN(val) && val > 0, 'Base price must be greater than 0')
      .optional(),
    currency: z.string().min(1).max(10).optional(),
    size: z.string().max(50).optional(),
    beds: z.string().max(50).optional(),
    view: z.string().max(50).optional(),
    images: z.string().optional(),
    amenities: z.string().optional(),
    active: z.boolean().optional(),
  }),
})

export const adminRoomIdParamSchema = z.object({
  id: z.string().cuid('Invalid room ID'),
})

// Admin Booking
export const adminBookingIdParamSchema = z.object({
  id: z.string().cuid('Invalid booking ID'),
})

export const adminBookingStatusSchema = z.object({
  params: z.object({ id: z.string().cuid() }),
  body: z.object({
    status: z.enum(['PENDING', 'CONFIRMED', 'CHECKED_IN', 'CHECKED_OUT', 'CANCELLED']),
  }),
})

// Admin Dining
export const adminDiningIdParamSchema = z.object({
  id: z.string().cuid('Invalid dining reservation ID'),
})

export const adminDiningStatusSchema = z.object({
  params: z.object({ id: z.string().cuid() }),
  body: z.object({
    status: z.enum(['PENDING', 'CONFIRMED', 'CANCELLED', 'COMPLETED']),
  }),
})

// Admin Contact
export const adminContactIdParamSchema = z.object({
  id: z.string().cuid('Invalid contact message ID'),
})

// Admin Review
export const adminReviewIdParamSchema = z.object({
  id: z.string().cuid('Invalid review ID'),
})

export const adminReviewApproveSchema = z.object({
  params: z.object({ id: z.string().cuid() }),
  body: z.object({
    approved: z.boolean(),
  }),
})