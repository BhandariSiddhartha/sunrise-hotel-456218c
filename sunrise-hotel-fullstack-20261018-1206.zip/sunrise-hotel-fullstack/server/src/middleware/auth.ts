import { Request, Response, NextFunction } from 'express'
import { prisma } from '../config/db'
import { config } from '../config/index'
import { logger } from '../utils/logger'
import { Role } from '../types'

/**
 * Authenticate admin session. Looks for a session token in the Authorization header
 * (Bearer <token>) or in the session cookie.
 */
export const authenticateAdmin = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const authHeader = req.headers.authorization
    const token = authHeader?.startsWith('Bearer ')
      ? authHeader.slice(7)
      : (req.cookies?.sessionToken as string | undefined)

    if (!token) {
      res.status(401).json({ error: 'Authentication required' })
      return
    }

    const session = await prisma.adminSession.findUnique({
      where: { tokenHash: token },
      include: { adminUser: true },
    })

    if (!session || session.expiresAt < new Date()) {
      res.status(401).json({ error: 'Session expired or invalid' })
      return
    }

    if (!session.adminUser.isActive) {
      res.status(401).json({ error: 'Account deactivated' })
      return
    }

    req.adminUser = {
      id: session.adminUser.id,
      email: session.adminUser.email,
      role: session.adminUser.role as Role,
    }

    next()
  } catch (error) {
    logger.error({ err: error, msg: 'Auth middleware error' })
    res.status(500).json({ error: 'Authentication error' })
  }
}

/**
 * Role-based access control middleware
 */
export const authorizeRoles = (...allowedRoles: Role[]) => {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (!req.adminUser) {
      res.status(401).json({ error: 'Authentication required' })
      return
    }

    if (!allowedRoles.includes(req.adminUser.role)) {
      res.status(403).json({ error: 'Insufficient permissions' })
      return
    }

    next()
  }
}

export const requireSuperAdmin = authorizeRoles('SUPER_ADMIN')
export const requireAdmin = authorizeRoles('SUPER_ADMIN', 'ADMIN')
export const requireStaff = authorizeRoles('SUPER_ADMIN', 'ADMIN', 'STAFF')