import { Router } from 'express'
import { authRateLimit, bookingRateLimit, contactRateLimit, chatbotRateLimit } from '../../middleware/rateLimit'
import { authenticateAdmin, requireStaff, requireAdmin, requireSuperAdmin } from '../../middleware/auth'
import {
  getRooms,
  getRoomById,
  getRoomAvailability,
  createRoom,
  updateRoom,
  deleteRoom,
} from '../../controllers/roomsController'
import {
  createBookingController,
  getBooking,
  cancelBookingController,
} from '../../controllers/bookingsController'
import { createDiningReservation } from '../../controllers/diningController'
import { createContactMessage } from '../../controllers/contactController'
import { getReviews, createReview } from '../../controllers/reviewsController'
import { getOffers } from '../../controllers/offersController'
import {
  adminLogin,
  adminLogout,
  adminMe,
} from '../../controllers/adminAuthController'
import {
  adminCreateRoom,
  adminUpdateRoom,
  adminDeleteRoom,
  adminListBookings,
  adminUpdateBookingStatus,
  adminListDining,
  adminUpdateDiningStatus,
  adminListContact,
  adminMarkContactRead,
  adminListReviews,
  adminModerateReview,
  adminCreateOffer,
  adminUpdateOffer,
  adminDeleteOffer,
  adminDashboardStats,
  adminOccupancyReport,
} from '../../controllers/adminController'

const router = Router()

// ===== Health =====
router.get('/health', async (_req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() })
})

// ===== Rooms (Public) =====
router.get('/rooms/availability', getRoomAvailability)
router.get('/rooms', getRooms)
router.get('/rooms/:id', getRoomById)

// ===== Bookings (Public) =====
router.post('/bookings', bookingRateLimit, createBookingController)
router.post('/bookings/verify', bookingRateLimit, getBooking)
router.post('/bookings/:reference/cancel', bookingRateLimit, cancelBookingController)

// ===== Dining (Public) =====
router.post('/dining-reservations', contactRateLimit, createDiningReservation)

// ===== Contact (Public) =====
router.post('/contact', contactRateLimit, createContactMessage)

// ===== Reviews (Public) =====
router.get('/reviews', getReviews)
router.post('/reviews', contactRateLimit, createReview)

// ===== Offers (Public) =====
router.get('/offers', getOffers)

// ===== Chatbot (Public) =====
router.post('/chatbot', chatbotRateLimit, async (req, res) => {
  const { chatbotService } = await import('../../services/chatbotService')
  const { question } = req.body
  if (!question || typeof question !== 'string') {
    res.status(400).json({ error: 'Question is required' })
    return
  }
  const response = await chatbotService.answer(question)
  res.json(response)
})

// ===== Admin Auth (Public - rate limited) =====
router.post('/admin/auth/login', authRateLimit, adminLogin)
router.post('/admin/auth/logout', adminLogout)
router.get('/admin/auth/me', authenticateAdmin, adminMe)

// ===== Admin Rooms (Authenticated + RBAC) =====
router.post('/admin/rooms', authenticateAdmin, requireAdmin, adminCreateRoom)
router.patch('/admin/rooms/:id', authenticateAdmin, requireAdmin, adminUpdateRoom)
router.delete('/admin/rooms/:id', authenticateAdmin, requireSuperAdmin, adminDeleteRoom)

// ===== Admin Bookings =====
router.get('/admin/bookings', authenticateAdmin, requireStaff, adminListBookings)
router.patch(
  '/admin/bookings/:id/status',
  authenticateAdmin,
  requireStaff,
  adminUpdateBookingStatus
)

// ===== Admin Dining =====
router.get(
  '/admin/dining-reservations',
  authenticateAdmin,
  requireStaff,
  adminListDining
)
router.patch(
  '/admin/dining-reservations/:id/status',
  authenticateAdmin,
  requireStaff,
  adminUpdateDiningStatus
)

// ===== Admin Contact =====
router.get(
  '/admin/contact-messages',
  authenticateAdmin,
  requireStaff,
  adminListContact
)
router.patch(
  '/admin/contact-messages/:id/read',
  authenticateAdmin,
  requireStaff,
  adminMarkContactRead
)

// ===== Admin Reviews (Moderation) =====
router.get(
  '/admin/reviews',
  authenticateAdmin,
  requireStaff,
  adminListReviews
)
router.patch(
  '/admin/reviews/:id/approve',
  authenticateAdmin,
  requireStaff,
  adminModerateReview
)

// ===== Admin Offers =====
router.post('/admin/offers', authenticateAdmin, requireAdmin, adminCreateOffer)
router.patch(
  '/admin/offers/:id',
  authenticateAdmin,
  requireAdmin,
  adminUpdateOffer
)
router.delete(
  '/admin/offers/:id',
  authenticateAdmin,
  requireSuperAdmin,
  adminDeleteOffer
)

// ===== Admin Dashboard =====
router.get(
  '/admin/dashboard/stats',
  authenticateAdmin,
  requireStaff,
  adminDashboardStats
)
router.get(
  '/admin/occupancy',
  authenticateAdmin,
  requireStaff,
  adminOccupancyReport
)

export default router