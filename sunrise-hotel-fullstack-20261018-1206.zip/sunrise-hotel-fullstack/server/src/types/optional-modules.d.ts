declare module '@anthropic-ai/sdk' {
  export class Anthropic {
    constructor(opts: { apiKey: string })
    messages: {
      create(opts: any): Promise<any>
    }
  }
}

declare module 'razorpay' {
  class Razorpay {
    constructor(opts: { key_id: string; key_secret: string })
    orders: {
      create(opts: any): Promise<any>
    }
  }
  export default Razorpay
}

declare module 'stripe' {
  function Stripe(key: string, opts?: any): any
  namespace Stripe {
    namespace webhooks {
      function constructEvent(
        payload: string | Buffer,
        signature: string,
        secret: string
      ): any
    }
  }
  export = Stripe
}