import { Role } from './types'

declare global {
  namespace Express {
    interface Request {
      adminUser?: {
        id: string
        email: string
        role: Role
      }
      cookies?: Record<string, string>
    }
  }
}