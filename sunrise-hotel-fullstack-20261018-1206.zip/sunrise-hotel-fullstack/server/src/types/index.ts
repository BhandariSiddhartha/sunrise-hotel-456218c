import { Request } from 'express'

export type BookingStatus = 'PENDING' | 'CONFIRMED' | 'CHECKED_IN' | 'CHECKED_OUT' | 'CANCELLED'
export type PaymentStatus = 'UNPAID' | 'PAID' | 'REFUNDED' | 'FAILED'
export type ReservationStatus = 'PENDING' | 'CONFIRMED' | 'CANCELLED' | 'COMPLETED'
export type ContactStatus = 'NEW' | 'READ' | 'RESPONDED' | 'ARCHIVED'
export type Role = 'SUPER_ADMIN' | 'ADMIN' | 'STAFF'

export type RoleString = Role