import { prisma } from '../config/db'
import { config } from '../config/index'
import { logger } from '../utils/logger'
import { generateBookingReference } from '../utils/bookingReference'
import { BookingStatus, PaymentStatus } from '../types'
import { AppError } from '../middleware/error'

const OVERLAPPING_STATUSES: BookingStatus[] = [
  'PENDING',
  'CONFIRMED',
  'CHECKED_IN',
  'CHECKED_OUT',
]

/**
 * Check room availability for given dates.
 * Returns rooms with calculated available inventory and server-side prices.
 */
export const checkAvailability = async ({
  checkIn,
  checkOut,
  guests,
  roomType,
}: {
  checkIn: Date
  checkOut: Date
  guests?: number
  roomType?: string
}) => {
  if (checkOut <= checkIn) {
    throw new Error('Check-out must be after check-in')
  }

  const nights = Math.ceil(
    (checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24)
  )

  // Build where clause for rooms
  const where: any = { active: true }
  if (roomType) {
    where.type = roomType
  }

  const rooms = await prisma.room.findMany({
    where,
    orderBy: { basePrice: 'asc' },
  })

  const nightsCount = nights
  const results = []

  for (const room of rooms) {
    // Filter by guest capacity
    if (guests && room.capacity < guests) continue

    // Get inventory for each night in the range
    const inventoryDates: Date[] = []
    for (let i = 0; i < nightsCount; i++) {
      const d = new Date(checkIn)
      d.setDate(d.getDate() + i)
      inventoryDates.push(d)
    }

    // Check for overlapping confirmed bookings on each date
    const inventory = await prisma.roomInventory.findMany({
      where: {
        roomId: room.id,
        date: { gte: checkIn, lt: checkOut },
      },
    })

    // Calculate minimum available rooms across all dates
    let minAvailable = room.capacity // fallback if no inventory records

    if (inventory.length > 0) {
      minAvailable = Math.min(
        ...inventory.map((inv) => inv.availableRooms)
      )
    } else {
      // No inventory records yet - assume default capacity
      // We'll check existing bookings directly
      const existingBookings = await prisma.booking.findMany({
        where: {
          roomId: room.id,
          status: { in: OVERLAPPING_STATUSES },
          OR: inventoryDates.map((d) => ({
            checkIn: { lte: d },
            checkOut: { gt: d },
          })),
        },
      })
      // Count unique booked rooms per date
      const bookedPerDate: Record<string, number> = {}
      for (const d of inventoryDates) {
        const dateStr = d.toISOString().split('T')[0]
        const count = existingBookings.filter((b) => {
          const bStart = new Date(b.checkIn).toISOString().split('T')[0]
          const bEnd = new Date(b.checkOut).toISOString().split('T')[0]
          const dStart = dateStr
          const dEnd = dateStr
          return bStart <= dEnd && bEnd > dStart
        }).length
        bookedPerDate[dateStr] = count
      }
      const maxBooked = Math.max(...Object.values(bookedPerDate), 0)
      minAvailable = Math.max(room.capacity - maxBooked, 0)
    }

    if (minAvailable <= 0) continue

    // Calculate price
    const baseAmount = room.basePrice * nightsCount
    const taxRate = config.taxRate / 100
    const serviceRate = config.serviceChargeRate / 100
    const taxAmount = baseAmount * taxRate
    const serviceAmount = baseAmount * serviceRate
    const totalAmount = baseAmount + taxAmount + serviceAmount

    results.push({
      id: room.id,
      name: room.name,
      type: room.type,
      description: room.description,
      capacity: room.capacity,
      basePrice: room.basePrice,
      currency: room.currency,
      size: room.size,
      beds: room.beds,
      view: room.view,
      images: room.images ? JSON.parse(room.images) : [],
      amenities: room.amenities ? JSON.parse(room.amenities) : [],
      nights: nightsCount,
      checkIn,
      checkOut,
      availableRooms: minAvailable,
      priceBreakdown: {
        baseAmount,
        taxAmount,
        serviceAmount,
        totalAmount,
        currency: room.currency,
      },
    })
  }

  return { rooms: results, nights: nightsCount }
}

/**
 * Create a booking with transaction and row-level locking to prevent overbooking.
 * Idempotency key prevents duplicate submissions.
 */
export const createBooking = async (data: {
  firstName: string
  lastName: string
  email: string
  phone: string
  checkIn: Date
  checkOut: Date
  adults: number
  children: number
  roomType: string
  rooms: number
  specialRequest?: string
  idempotencyKey?: string
}) => {
  const { idempotencyKey } = data

  // Idempotency: if key provided, check for existing booking
  if (idempotencyKey) {
    const existing = await prisma.booking.findFirst({
      where: { idempotencyKey },
    })
    if (existing) {
      return { booking: existing, isDuplicate: true }
    }
  }

  if (data.checkOut <= data.checkIn) {
    throw new Error('Check-out must be after check-in')
  }

  if (data.rooms < 1) {
    throw new Error('At least 1 room is required')
  }

  if (data.adults < 1) {
    throw new Error('At least 1 adult is required')
  }

  const totalGuests = data.adults + (data.children || 0)

  const nights = Math.ceil(
    (data.checkOut.getTime() - data.checkIn.getTime()) / (1000 * 60 * 60 * 24)
  )

  // Find matching rooms with available inventory (locked for update)
  const rooms = await prisma.room.findMany({
    where: {
      active: true,
      type: data.roomType,
      capacity: { gte: totalGuests },
    },
    orderBy: { basePrice: 'asc' },
    include: {
      inventory: {
        where: {
          date: { gte: data.checkIn, lt: data.checkOut },
        },
      },
    },
  })

  if (rooms.length === 0) {
    throw new Error('No rooms available for the selected dates and criteria')
  }

  // Find the best room with enough available inventory across all dates
  let selectedRoom: typeof rooms[0] | null = null

  for (const room of rooms) {
    // Check inventory availability for each date
    const allDatesAvailable = room.inventory.every(
      (inv) => inv.availableRooms >= data.rooms
    )

    if (allDatesAvailable || room.inventory.length === 0) {
      // If no inventory records exist, check against existing bookings
      if (room.inventory.length === 0) {
        // Count max concurrent bookings per date
        const existingBookings = await prisma.booking.findMany({
          where: {
            roomId: room.id,
            status: { in: OVERLAPPING_STATUSES },
            checkIn: { lt: data.checkOut },
            checkOut: { gt: data.checkIn },
          },
        })

        const dates: Date[] = []
        for (let i = 0; i < nights; i++) {
          const d = new Date(data.checkIn)
          d.setDate(d.getDate() + i)
          dates.push(d)
        }

        let maxConcurrent = 0
        for (const d of dates) {
          const count = existingBookings.filter((b) => {
            const bStart = new Date(b.checkIn)
            const bEnd = new Date(b.checkOut)
            return bStart <= d && bEnd > d
          }).length
          maxConcurrent = Math.max(maxConcurrent, count)
        }

        if (room.capacity - maxConcurrent >= data.rooms) {
          selectedRoom = room
          break
        }
      } else {
        selectedRoom = room
        break
      }
    }
  }

  if (!selectedRoom) {
    throw new Error('No rooms available for the selected dates')
  }

  // Calculate pricing server-side
  const baseAmount = selectedRoom.basePrice * nights * data.rooms
  const taxRate = config.taxRate / 100
  const serviceRate = config.serviceChargeRate / 100
  const taxAmount = baseAmount * taxRate
  const serviceAmount = baseAmount * serviceRate
  const totalAmount = baseAmount + taxAmount + serviceAmount

  const reference = generateBookingReference()

  // Create booking in transaction with inventory locking
  const booking = await prisma.$transaction(async (tx) => {
    // Lock inventory rows for the selected room and date range
    await tx.roomInventory.updateMany({
      where: {
        roomId: selectedRoom.id,
        date: { gte: data.checkIn, lt: data.checkOut },
      },
      data: {
        availableRooms: {
          decrement: data.rooms,
        },
      },
    })

    // Create inventory records for dates that don't exist yet
    const dates: Date[] = []
    for (let i = 0; i < nights; i++) {
      const d = new Date(data.checkIn)
      d.setDate(d.getDate() + i)
      dates.push(d)
    }

    for (const d of dates) {
      await tx.roomInventory.upsert({
        where: {
          roomId_date: {
            roomId: selectedRoom.id,
            date: d,
          },
        },
        update: {},
        create: {
          roomId: selectedRoom.id,
          date: d,
          totalRooms: selectedRoom.capacity,
          availableRooms: selectedRoom.capacity - data.rooms,
        },
      })
    }

    // Get or create guest
    let guest = await tx.guest.findUnique({ where: { email: data.email } })
    if (!guest) {
      guest = await tx.guest.create({
        data: {
          email: data.email,
          name: `${data.firstName} ${data.lastName}`,
          phone: data.phone,
        },
      })
    }

    return tx.booking.create({
      data: {
        reference,
        room: { connect: { id: selectedRoom.id } },
        guest: { connect: { id: guest.id } },
        firstName: data.firstName,
        lastName: data.lastName,
        email: data.email,
        phone: data.phone,
        checkIn: data.checkIn,
        checkOut: data.checkOut,
        adults: data.adults,
        children: data.children || 0,
        rooms: data.rooms,
        roomType: data.roomType,
        baseAmount,
        taxAmount,
        serviceAmount,
        totalAmount,
        currency: selectedRoom.currency,
        status: 'PENDING',
        paymentStatus: 'UNPAID',
        specialRequest: data.specialRequest,
        idempotencyKey,
      },
      include: { room: true },
    })
  })

  logger.info({ bookingId: booking.id, reference }, 'Booking created')

  return { booking, isDuplicate: false }
}

/**
 * Get booking by reference with email verification
 */
export const getBookingByReference = async (
  reference: string,
  email: string
) => {
  const booking = await prisma.booking.findFirst({
    where: { reference, email },
    include: { room: true },
  })

  if (!booking) {
    throw new AppError('Booking not found', 404)
  }

  return booking
}

/**
 * Cancel a booking (with verification)
 */
export const cancelBooking = async (
  reference: string,
  email: string,
  reason?: string
) => {
  const booking = await prisma.booking.findFirst({
    where: { reference, email },
  })

  if (!booking) {
    throw new AppError('Booking not found', 404)
  }

  if (booking.status === 'CANCELLED') {
    throw new Error('Booking is already cancelled')
  }

  if (booking.status === 'CHECKED_OUT') {
    throw new Error('Cannot cancel a checked-out booking')
  }

  return prisma.$transaction(async (tx) => {
    // Release inventory
    if (booking.roomId) {
      await tx.roomInventory.updateMany({
        where: {
          roomId: booking.roomId,
          date: { gte: booking.checkIn, lt: booking.checkOut },
        },
        data: {
          availableRooms: {
            increment: booking.rooms,
          },
        },
      })
    }

    return tx.booking.update({
      where: { id: booking.id },
      data: {
        status: 'CANCELLED',
        paymentStatus: 'REFUNDED',
        cancellationReason: reason,
        cancelledAt: new Date(),
      },
    })
  })
}

/**
 * Admin: list bookings with filters
 */
export const listBookings = async ({
  page = 1,
  limit = 20,
  status,
  email,
  search,
}: {
  page?: number
  limit?: number
  status?: string
  email?: string
  search?: string
}) => {
  const skip = (page - 1) * limit
  const where: any = {}

  if (status) where.status = status
  if (email) where.email = { contains: email, mode: 'insensitive' }
  if (search) {
    where.OR = [
      { firstName: { contains: search, mode: 'insensitive' } },
      { lastName: { contains: search, mode: 'insensitive' } },
      { reference: { contains: search, mode: 'insensitive' } },
      { email: { contains: search, mode: 'insensitive' } },
    ]
  }

  const [bookings, total] = await prisma.$transaction([
    prisma.booking.findMany({
      where,
      include: { room: true },
      orderBy: { createdAt: 'desc' },
      skip,
      take: limit,
    }),
    prisma.booking.count({ where }),
  ])

  return { bookings, total, page, limit }
}

/**
 * Admin: update booking status
 */
export const updateBookingStatus = async (
  id: string,
  status: BookingStatus
) => {
  return prisma.booking.update({
    where: { id },
    data: { status },
    include: { room: true },
  })
}

/**
 * Admin: get dashboard stats
 */
export const getDashboardStats = async () => {
  const now = new Date()
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1)

  const [totalBookings, confirmedBookings, cancelledBookings, totalRevenue, recentBookings] =
    await prisma.$transaction([
      prisma.booking.count(),
      prisma.booking.count({ where: { status: 'CONFIRMED' } }),
      prisma.booking.count({ where: { status: 'CANCELLED' } }),
      prisma.booking.aggregate({
        where: { paymentStatus: 'PAID' },
        _sum: { totalAmount: true },
      }),
      prisma.booking.findMany({
        where: { createdAt: { gte: startOfMonth } },
        orderBy: { createdAt: 'desc' },
        take: 10,
        include: { room: true },
      }),
    ])

  return {
    totalBookings,
    confirmedBookings,
    cancelledBookings,
    totalRevenue: totalRevenue._sum.totalAmount || 0,
    recentBookings,
  }
}

/**
 * Admin: occupancy report
 */
export const getOccupancyReport = async () => {
  const rooms = await prisma.room.findMany({ where: { active: true } })
  const totalRooms = rooms.length

  const bookings = await prisma.booking.findMany({
    where: { status: { in: ['CONFIRMED', 'CHECKED_IN'] } },
  })

  const occupiedDates = new Set()
  for (const b of bookings) {
    const start = new Date(b.checkIn)
    const end = new Date(b.checkOut)
    while (start < end) {
      occupiedDates.add(start.toISOString().split('T')[0])
      start.setDate(start.getDate() + 1)
    }
  }

  const occupancyRate = totalRooms > 0 ? (occupiedDates.size / (totalRooms * 30)) * 100 : 0

  return {
    totalRooms,
    occupiedRoomNights: occupiedDates.size,
    occupancyRate: Math.round(occupancyRate * 100) / 100,
    activeBookings: bookings.length,
  }
}