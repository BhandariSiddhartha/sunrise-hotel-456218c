import nodemailer from 'nodemailer'
import { config } from '../config/index'
import { logger } from '../utils/logger'

let transporter: nodemailer.Transporter | null = null

const getTransporter = () => {
  if (!config.smtpHost || !config.smtpUser || !config.smtpPass) {
    return null
  }
  if (!transporter) {
    transporter = nodemailer.createTransport({
      host: config.smtpHost,
      port: config.smtpPort,
      secure: config.smtpPort === 465,
      auth: {
        user: config.smtpUser,
        pass: config.smtpPass,
      },
    })
  }
  return transporter
}

export const isEmailConfigured = (): boolean => {
  return Boolean(config.smtpHost && config.smtpUser && config.smtpPass)
}

export const sendEmail = async ({
  to,
  subject,
  html,
  text,
}: {
  to: string
  subject: string
  html?: string
  text?: string
}): Promise<boolean> => {
  const transport = getTransporter()
  if (!transport) {
    logger.warn({ to, subject }, 'Email not configured - skipping send')
    return false
  }

  try {
    await transport.sendMail({
      from: config.smtpFrom,
      to,
      subject,
      html,
      text,
    })
    logger.info({ to, subject }, 'Email sent')
    return true
  } catch (error) {
    logger.error({ err: error, to, subject }, 'Failed to send email')
    return false
  }
}

export const emailTemplates = {
  bookingConfirmation: (
    name: string,
    reference: string,
    checkIn: string,
    checkOut: string,
    roomName: string,
    totalAmount: number,
    currency: string
  ) => ({
    subject: `Booking Confirmed - ${reference}`,
    html: `
      <h2>Dear ${name},</h2>
      <p>Your booking at Sunrise Hotels &amp; Resorts has been confirmed.</p>
      <p><strong>Reference:</strong> ${reference}</p>
      <p><strong>Room:</strong> ${roomName}</p>
      <p><strong>Check-in:</strong> ${checkIn}</p>
      <p><strong>Check-out:</strong> ${checkOut}</p>
      <p><strong>Total:</strong> ${currency} ${totalAmount.toFixed(2)}</p>
      <p>Thank you for choosing Sunrise Hotels &amp; Resorts.</p>
    `,
    text: `Dear ${name},\nYour booking (${reference}) at Sunrise Hotels & Resorts is confirmed.\nRoom: ${roomName}\nCheck-in: ${checkIn}\nCheck-out: ${checkOut}\nTotal: ${currency} ${totalAmount.toFixed(2)}\n`,
  }),
  bookingCancellation: (
    name: string,
    reference: string
  ) => ({
    subject: `Booking Cancelled - ${reference}`,
    html: `
      <h2>Dear ${name},</h2>
      <p>Your booking <strong>${reference}</strong> at Sunrise Hotels &amp; Resorts has been cancelled.</p>
      <p>If you have any questions, please contact us.</p>
    `,
    text: `Dear ${name},\nYour booking (${reference}) at Sunrise Hotels & Resorts has been cancelled.\n`,
  }),
  diningConfirmation: (name: string, date: string, time: string, guests: number) => ({
    subject: 'Dining Reservation Confirmed',
    html: `
      <h2>Dear ${name},</h2>
      <p>Your dining reservation at Sunrise Hotels &amp; Resorts is confirmed.</p>
      <p><strong>Date:</strong> ${date}</p>
      <p><strong>Time:</strong> ${time}</p>
      <p><strong>Party size:</strong> ${guests}</p>
    `,
    text: `Dear ${name},\nYour dining reservation is confirmed.\nDate: ${date}\nTime: ${time}\nParty size: ${guests}\n`,
  }),
  contactReceipt: (name: string, subject: string) => ({
    subject: `We received your message: ${subject}`,
    html: `
      <h2>Dear ${name},</h2>
      <p>Thank you for contacting Sunrise Hotels &amp; Resorts. We have received your message and will respond shortly.</p>
    `,
    text: `Dear ${name},\nThank you for contacting Sunrise Hotels & Resorts. We have received your message and will respond shortly.\n`,
  }),
}

export const emailService = {
  sendEmail,
  isEmailConfigured,
  templates: emailTemplates,
}