import { prisma } from '../config/db'
import { config } from '../config/index'
import { logger } from '../utils/logger'

export interface ChatbotResponse {
  answer: string
  source: 'rule' | 'ai'
  data?: any
}

/**
 * Chatbot service that answers questions about hotel information.
 * Uses a configurable AI provider if available, otherwise falls back to rule-based responses.
 * Never exposes guest data, admin data, or private booking information.
 */
export class ChatbotService {
  private readonly aiProvider: 'none' | 'openai' | 'anthropic'

  constructor() {
    this.aiProvider = (config.aiProvider as any) || 'none'
  }

  async answer(question: string): Promise<ChatbotResponse> {
    const q = question.toLowerCase()

    // Rule-based responses for common queries - always available
    const ruleBased = this.tryRuleBased(q)
    if (ruleBased) return ruleBased

    // If AI provider configured, use it
    if (this.aiProvider === 'openai' && config.openaiApiKey) {
      return this.answerWithOpenAI(question)
    }
    if (this.aiProvider === 'anthropic' && config.anthropicApiKey) {
      return this.answerWithAnthropic(question)
    }

    // Final fallback
    return {
      answer: "I'm sorry, I don't have information about that. Please contact Sunrise Hotels & Resorts directly at info@sunrisehotel.com or +91 90004 84626.",
      source: 'rule',
    }
  }

  private tryRuleBased(q: string): ChatbotResponse | null {
    // Hours / dining
    if (q.includes('breakfast') || q.includes('lunch') || q.includes('dinner') || q.includes('restaurant') || q.includes('dining')) {
      return {
        answer: 'Our restaurant serves Breakfast 7–10 AM, Lunch 12–3 PM, and Dinner 7–11 PM. You can reserve a table through our website.',
        source: 'rule',
      }
    }

    // Check-in / check-out
    if (q.includes('check-in') || q.includes('checkin')) {
      return {
        answer: 'Check-in is at 3:00 PM. Early check-in may be available upon request, subject to availability.',
        source: 'rule',
      }
    }
    if (q.includes('check-out') || q.includes('checkout')) {
      return {
        answer: 'Check-out is at 11:00 AM. Late check-out can be arranged at the front desk for an additional fee.',
        source: 'rule',
      }
    }

    // Contact
    if (q.includes('contact') || q.includes('phone') || q.includes('email') || q.includes('address') || q.includes('location')) {
      return {
        answer: 'Sunrise Hotels & Resorts, Beach Road. Phone: +91 90004 84626. Email: info@sunrisehotel.com. We are minutes from the beach, airport, and railway station.',
        source: 'rule',
      }
    }

    // WhatsApp
    if (q.includes('whatsapp') || q.includes('chat')) {
      return {
        answer: 'You can reach us on WhatsApp at +91 90004 84626 or chat with me here!',
        source: 'rule',
      }
    }

    // Policies
    if (q.includes('cancellation') || q.includes('cancel') || q.includes('policy')) {
      return {
        answer: 'Cancellation policy varies by booking. Please check your booking confirmation or contact us with your booking reference for details.',
        source: 'rule',
      }
    }

    // Offers
    if (q.includes('offer') || q.includes('package') || q.includes('discount') || q.includes('deal')) {
      return {
        answer: 'We offer Weekend Escape (20% OFF Fri–Sun), Honeymoon Romance Package, Festival Celebration (up to 30% OFF), and Corporate Business Plan. Visit our Offers page for details.',
        source: 'rule',
      }
    }

    // Amenities
    if (q.includes('amenity') || q.includes('amenities') || q.includes('pool') || q.includes('wifi') || q.includes('spa') || q.includes('gym') || q.includes('parking')) {
      return {
        answer: 'We offer free Wi-Fi, swimming pool, spa, fitness center, parking, and room service. Specific amenities vary by room type.',
        source: 'rule',
      }
    }

    // Rooms
    if (q.includes('room') || q.includes('suite') || q.includes('accommodation')) {
      return {
        answer: 'We offer Deluxe, Luxury, Family, and Suite rooms. Check our Rooms page for current availability and prices.',
        source: 'rule',
      }
    }

    // Booking availability - direct to backend
    if (q.includes('available') || q.includes('availability') || q.includes('book')) {
      return {
        answer: 'Please use our booking widget to check real-time availability for your dates. I cannot check live availability directly.',
        source: 'rule',
      }
    }

    return null
  }

  private async answerWithOpenAI(question: string): Promise<ChatbotResponse> {
    try {
      const settings = await prisma.hotelSetting.findFirst()
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${config.openaiApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: config.openaiModel,
          messages: [
            {
              role: 'system',
              content: `You are the Sunrise Hotels & Resorts assistant. Answer only about hotel information: rooms, amenities, dining, policies, offers, check-in/out, and contact. Never invent availability, prices, or reservations. Never expose guest or admin data. If asked about live availability, direct the user to the booking widget. Hotel: ${settings?.hotelName || 'Sunrise Hotels & Resorts'}. Contact: ${settings?.contactEmail || 'info@sunrisehotel.com'}, ${settings?.contactPhone || '+91 90004 84626'}.`,
            },
            { role: 'user', content: question },
          ],
          temperature: 0.3,
          max_tokens: 300,
        }),
        signal: AbortSignal.timeout(20_000),
      })

      if (!response.ok) {
        throw new Error(`OpenAI request failed with status ${response.status}`)
      }

      const completion = await response.json() as {
        choices?: Array<{ message?: { content?: string | null } }>
      }
      const answer = completion.choices?.[0]?.message?.content?.trim()
      if (!answer) throw new Error('OpenAI returned an empty response')

      return { answer, source: 'ai' }
    } catch (error) {
      logger.error({ err: error }, 'OpenAI chatbot error')
      return {
        answer: "I'm having trouble connecting. Please contact Sunrise Hotels & Resorts directly.",
        source: 'rule',
      }
    }
  }

  private async answerWithAnthropic(question: string): Promise<ChatbotResponse> {
    try {
      const { Anthropic } = await import('@anthropic-ai/sdk')

      const anthropic = new Anthropic({ apiKey: config.anthropicApiKey })

      const settings = await prisma.hotelSetting.findFirst()

      const systemPrompt = `You are the Sunrise Hotels & Resorts assistant. Answer only about hotel information. Never invent availability, prices, or reservations. Never expose guest or admin data. Hotel: ${settings?.hotelName || 'Sunrise Hotels & Resorts'}.`

      const completion = await anthropic.messages.create({
        model: 'claude-3-haiku-20240307',
        max_tokens: 300,
        system: systemPrompt,
        messages: [{ role: 'user', content: question }],
      })

      const text = completion.content
        .filter((c: any) => c.type === 'text')
        .map((c: any) => c.text)
        .join('')

      return { answer: text, source: 'ai' }
    } catch (error) {
      logger.error({ err: error }, 'Anthropic chatbot error')
      return {
        answer: "I'm having trouble connecting. Please contact Sunrise Hotels & Resorts directly.",
        source: 'rule',
      }
    }
  }
}

export const chatbotService = new ChatbotService()