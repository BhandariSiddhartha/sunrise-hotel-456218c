import { config } from '../config/index'
import { logger } from '../utils/logger'

export type PaymentProvider = 'none' | 'razorpay' | 'stripe'

export interface PaymentResult {
  success: boolean
  providerPaymentId?: string
  error?: string
  raw?: any
}

export class PaymentService {
  private provider: PaymentProvider

  constructor() {
    this.provider = (config.paymentProvider as PaymentProvider) || 'none'
  }

  isEnabled(): boolean {
    return this.provider !== 'none'
  }

  /**
   * Create a payment order (Razorpay/Stripe) for a booking.
   * Returns client-side data needed to complete payment.
   */
  async createOrder(amount: number, currency: string, bookingReference: string): Promise<{
    provider: PaymentProvider
    orderId?: string
    clientSecret?: string
    publishableKey?: string
    error?: string
  }> {
    if (!this.isEnabled()) {
      return { provider: 'none', error: 'Payment provider not configured' }
    }

    if (this.provider === 'razorpay') {
      return this.createRazorpayOrder(amount, currency, bookingReference)
    }

    if (this.provider === 'stripe') {
      return this.createStripePaymentIntent(amount, currency, bookingReference)
    }

    return { provider: 'none', error: 'Unknown payment provider' }
  }

  private async createRazorpayOrder(
    amount: number,
    currency: string,
    bookingReference: string
  ): Promise<{
    provider: PaymentProvider
    orderId?: string
    publishableKey?: string
    error?: string
  }> {
    if (!config.razorpayKeyId || !config.razorpayKeySecret) {
      return { provider: 'razorpay', error: 'Razorpay credentials not configured' }
    }

    try {
      // Dynamic import to avoid hard dependency when not configured
      const Razorpay = (await import('razorpay')).default
      const razorpay = new Razorpay({
        key_id: config.razorpayKeyId,
        key_secret: config.razorpayKeySecret,
      })

      const order = await razorpay.orders.create({
        amount: Math.round(amount * 100), // Razorpay uses smallest currency unit
        currency,
        receipt: bookingReference,
        notes: { bookingReference },
      })

      return {
        provider: 'razorpay',
        orderId: order.id,
        publishableKey: config.razorpayKeyId,
      }
    } catch (error) {
      logger.error({ err: error, bookingReference }, 'Razorpay order creation failed')
      return { provider: 'razorpay', error: 'Failed to create payment order' }
    }
  }

  private async createStripePaymentIntent(
    amount: number,
    currency: string,
    bookingReference: string
  ): Promise<{
    provider: PaymentProvider
    clientSecret?: string
    error?: string
  }> {
    if (!config.stripeSecretKey) {
      return { provider: 'stripe', error: 'Stripe credentials not configured' }
    }

    try {
      const stripe = (await import('stripe')).default(config.stripeSecretKey)

      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Stripe uses cents
        currency: currency.toLowerCase(),
        metadata: { bookingReference },
      })

      return {
        provider: 'stripe',
        clientSecret: paymentIntent.client_secret,
      }
    } catch (error) {
      logger.error({ err: error, bookingReference }, 'Stripe payment intent failed')
      return { provider: 'stripe', error: 'Failed to create payment intent' }
    }
  }

  /**
   * Verify a webhook signature and extract payment status.
   * Must be called by webhook routes.
   */
  async verifyWebhook(
    payload: string | Buffer,
    signature: string
  ): Promise<{ eventType: string; paymentId: string; status: string; bookingReference?: string } | null> {
    if (!this.isEnabled()) return null

    if (this.provider === 'razorpay') {
      return this.verifyRazorpayWebhook(payload, signature)
    }

    if (this.provider === 'stripe') {
      return this.verifyStripeWebhook(payload, signature)
    }

    return null
  }

  private async verifyRazorpayWebhook(
    payload: string | Buffer,
    signature: string
  ) {
    const crypto = await import('crypto')
    const expected = crypto
      .createHmac('sha256', config.razorpayKeySecret)
      .update(payload)
      .digest('hex')

    if (expected !== signature) {
      logger.warn('Razorpay webhook signature mismatch')
      return null
    }

    const event = JSON.parse(typeof payload === 'string' ? payload : payload.toString())
    return {
      eventType: event.event,
      paymentId: event.payload?.payment?.entity?.id || '',
      status: event.payload?.payment?.entity?.status || 'unknown',
      bookingReference: event.payload?.payment?.entity?.notes?.bookingReference,
    }
  }

  private async verifyStripeWebhook(
    payload: string | Buffer,
    signature: string
  ) {
    const stripe = (await import('stripe')).default(config.stripeSecretKey)

    let event: any
    try {
      event = stripe.webhooks.constructEvent(
        payload,
        signature,
        config.stripeWebhookSecret
      )
    } catch (error) {
      logger.warn({ err: error }, 'Stripe webhook signature mismatch')
      return null
    }

    const paymentIntent = event.data.object
    return {
      eventType: event.type,
      paymentId: paymentIntent.id,
      status: paymentIntent.status,
      bookingReference: paymentIntent.metadata?.bookingReference,
    }
  }
}

export const paymentService = new PaymentService()