import pino from 'pino'

const redactPaths = [
  'password',
  'passwordHash',
  'token',
  'session',
  'authorization',
  'cookie',
  'secret',
  'key',
  'razorpayKeySecret',
  'stripeSecretKey',
  'stripeWebhookSecret',
  'smtpPass',
]

export const logger = pino({
  level: process.env.LOG_LEVEL || 'info',
  redact: redactPaths,
  transport:
    process.env.NODE_ENV === 'development'
      ? { target: 'pino-pretty', options: { colorize: true, translateTime: 'SYS HH:MM:ss' } }
      : undefined,
})