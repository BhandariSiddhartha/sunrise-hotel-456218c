import { v4 as uuidv4 } from 'uuid'

const prefix = 'SRH'

export const generateBookingReference = (): string => {
  const short = uuidv4().replace(/-/g, '').slice(0, 8).toUpperCase()
  return `${prefix}-${short}`
}