import express from 'express'
import cors from 'cors'
import session from 'express-session'
import cookieParser from 'cookie-parser'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { config } from './config/index'
import { prisma } from './config/db'
import { logger } from './utils/logger'
import v1Routes from './routes/v1'
import { securityHeaders, corsOptions } from './middleware/security'
import { errorHandler, asyncHandler, AppError } from './middleware/error'
import { apiRateLimit } from './middleware/rateLimit'
import { createInitialAdmin } from './controllers/adminAuthController'

const app = express()
const publicDirectory = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../public')

// Trust proxy (needed for secure cookies behind Render/Netlify)
app.set('trust proxy', 1)

// Security headers
app.use(securityHeaders)

// CORS
app.use(cors(corsOptions))

// Body parsing with size limits
app.use(express.json({ limit: '100kb' }))
app.use(express.urlencoded({ extended: true, limit: '100kb' }))

// Cookie parser
app.use(cookieParser())

// Session (in-memory store for dev; production should use connect-pg-simple with PostgreSQL)
app.use(
  session({
    secret: config.sessionSecret,
    name: 'sunrise_session',
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: config.isProduction,
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    },
  })
)

// Global rate limit
app.use(apiRateLimit)

// Health check
app.get('/api/v1/health', asyncHandler(async (_req, res) => {
  await prisma.$queryRaw`SELECT 1`
  res.json({ status: 'ok', timestamp: new Date().toISOString() })
}))

// API routes
app.use(config.apiBaseUrl, v1Routes)

app.use(express.static(publicDirectory))

// 404 handler
app.use(asyncHandler(async (_req, _res, next) => {
  throw new AppError('Not found', 404)
}))

// Error handler (must be last)
app.use(errorHandler)

// Start server
async function start() {
  try {
    // Connect to DB
    await prisma.$connect()
    logger.info('Database connected')

    // Seed initial admin if configured
    try {
      await createInitialAdmin(
        config.adminEmail,
        config.adminPassword,
        'SUPER_ADMIN'
      )
    } catch (e) {
      logger.warn({ err: e }, 'Could not seed initial admin (may already exist)')
    }

    app.listen(config.port, () => {
      logger.info(`Sunrise Hotels API running on port ${config.port} (${config.nodeEnv})`)
      logger.info(`API base: ${config.apiBaseUrl}`)
      logger.info(`Health: http://localhost:${config.port}${config.apiBaseUrl}/health`)
    })
  } catch (error) {
    logger.error({ err: error }, 'Failed to start server')
    process.exit(1)
  }
}

start()

// Graceful shutdown
process.on('SIGTERM', async () => {
  logger.info('SIGTERM received, shutting down')
  await prisma.$disconnect()
  process.exit(0)
})

process.on('SIGINT', async () => {
  logger.info('SIGINT received, shutting down')
  await prisma.$disconnect()
  process.exit(0)
})
