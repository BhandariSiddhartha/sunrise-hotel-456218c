import { PrismaClient } from '@prisma/client'
import { config } from './index'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: config.logLevel === 'info' ? ['query', 'info', 'warn', 'error'] : ['error'],
  })

if (config.nodeEnv !== 'production') globalForPrisma.prisma = prisma