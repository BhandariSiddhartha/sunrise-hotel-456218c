import dotenv from 'dotenv'

dotenv.config()

const requiredEnv = (key: string): string => {
  const value = process.env[key]
  if (!value) {
    throw new Error(`Missing required environment variable: ${key}`)
  }
  return value
}

export const config = {
  port: Number.parseInt(process.env.PORT || '4000', 10),
  nodeEnv: process.env.NODE_ENV || 'development',
  apiBaseUrl: process.env.API_BASE_URL || '/api/v1',
  clientUrl: process.env.CLIENT_URL || 'http://localhost:4000',
  databaseUrl: requiredEnv('DATABASE_URL'),
  sessionSecret: requiredEnv('SESSION_SECRET'),
  adminEmail: process.env.ADMIN_EMAIL || 'admin@sunrisehotel.example',
  adminPassword: process.env.ADMIN_PASSWORD || 'change-me-in-production',
  smtpHost: process.env.SMTP_HOST || '',
  smtpPort: Number.parseInt(process.env.SMTP_PORT || '587', 10),
  smtpUser: process.env.SMTP_USER || '',
  smtpPass: process.env.SMTP_PASS || '',
  smtpFrom: process.env.SMTP_FROM || 'noreply@sunrisehotel.example',
  taxRate: (() => { const v = Number.parseFloat(process.env.TAX_RATE || '0'); return Number.isNaN(v) ? 0 : v })(),
  serviceChargeRate: (() => { const v = Number.parseFloat(process.env.SERVICE_CHARGE_RATE || '0'); return Number.isNaN(v) ? 0 : v })(),
  paymentProvider: process.env.PAYMENT_PROVIDER || 'none',
  razorpayKeyId: process.env.RAZORPAY_KEY_ID || '',
  razorpayKeySecret: process.env.RAZORPAY_KEY_SECRET || '',
  stripeSecretKey: process.env.STRIPE_SECRET_KEY || '',
  stripeWebhookSecret: process.env.STRIPE_WEBHOOK_SECRET || '',
  aiProvider: process.env.AI_PROVIDER || 'none',
  openaiApiKey: process.env.OPENAI_API_KEY || '',
  openaiModel: process.env.OPENAI_MODEL || 'gpt-4o-mini',
  anthropicApiKey: process.env.ANTHROPIC_API_KEY || '',
  logLevel: process.env.LOG_LEVEL || 'info',
  isProduction: process.env.NODE_ENV === 'production',
  isDevelopment: process.env.NODE_ENV === 'development',
} as const

export type Config = typeof config
