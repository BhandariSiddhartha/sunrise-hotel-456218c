import { Request, Response } from 'express'
import { asyncHandler } from '../middleware/error'
import {
  adminRoomCreateSchema,
  adminRoomUpdateSchema,
  adminRoomIdParamSchema,
  adminBookingIdParamSchema,
  adminBookingStatusSchema,
  adminDiningIdParamSchema,
  adminDiningStatusSchema,
  adminContactIdParamSchema,
  adminReviewIdParamSchema,
  adminReviewApproveSchema,
  offerCreateSchema,
  offerIdParamSchema,
} from '../middleware/validation'
import {
  listBookings,
  updateBookingStatus,
  getDashboardStats,
  getOccupancyReport,
} from '../services/bookingService'
import { prisma } from '../config/db'
import { logger } from '../utils/logger'

// ===== Rooms (Admin) =====

export const adminCreateRoom = asyncHandler(async (req: Request, res: Response) => {
  const { body } = adminRoomCreateSchema.parse(req)

  const room = await prisma.room.create({
    data: {
      name: body.name,
      type: body.type,
      description: body.description,
      capacity: body.capacity,
      basePrice: body.basePrice,
      currency: body.currency,
      size: body.size,
      beds: body.beds,
      view: body.view,
      images: body.images ? JSON.stringify(JSON.parse(body.images || '[]')) : '[]',
      amenities: body.amenities ? JSON.stringify(JSON.parse(body.amenities || '[]')) : '[]',
      active: body.active,
    },
  })

  logger.info({ adminId: req.adminUser?.id, roomId: room.id }, 'Admin created room')
  res.status(201).json({ room })
})

export const adminUpdateRoom = asyncHandler(async (req: Request, res: Response) => {
  const { id } = adminRoomIdParamSchema.parse(req.params)
  const body = adminRoomUpdateSchema.parse(req).body

  const room = await prisma.room.update({
    where: { id },
    data: {
      ...(body.name !== undefined && { name: body.name }),
      ...(body.type !== undefined && { type: body.type }),
      ...(body.description !== undefined && { description: body.description }),
      ...(body.capacity !== undefined && { capacity: body.capacity }),
      ...(body.basePrice !== undefined && { basePrice: body.basePrice }),
      ...(body.currency !== undefined && { currency: body.currency }),
      ...(body.size !== undefined && { size: body.size }),
      ...(body.beds !== undefined && { beds: body.beds }),
      ...(body.view !== undefined && { view: body.view }),
      ...(body.images !== undefined && {
        images: JSON.stringify(JSON.parse(body.images)),
      }),
      ...(body.amenities !== undefined && {
        amenities: JSON.stringify(JSON.parse(body.amenities)),
      }),
      ...(body.active !== undefined && { active: body.active }),
    },
  })

  res.json({ room })
})

export const adminDeleteRoom = asyncHandler(async (req: Request, res: Response) => {
  const { id } = adminRoomIdParamSchema.parse(req.params)

  const existing = await prisma.room.findUnique({ where: { id } })
  if (!existing) {
    res.status(404).json({ error: 'Room not found' })
    return
  }

  await prisma.room.delete({ where: { id } })
  res.status(204).send()
})

// ===== Bookings (Admin) =====

export const adminListBookings = asyncHandler(async (req: Request, res: Response) => {
  const page = parseInt(req.query.page as string) || 1
  const limit = parseInt(req.query.limit as string) || 20
  const status = req.query.status as string | undefined
  const email = req.query.email as string | undefined
  const search = req.query.search as string | undefined

  const result = await listBookings({ page, limit, status, email, search })
  res.json(result)
})

export const adminUpdateBookingStatus = asyncHandler(
  async (req: Request, res: Response) => {
    const { id } = adminBookingIdParamSchema.parse(req.params)
    const { status } = adminBookingStatusSchema.parse(req).body

    const booking = await updateBookingStatus(id, status)
    res.json({ booking })
  }
)

// ===== Dining Reservations (Admin) =====

export const adminListDining = asyncHandler(async (req: Request, res: Response) => {
  const page = parseInt(req.query.page as string) || 1
  const limit = parseInt(req.query.limit as string) || 20
  const status = req.query.status as string | undefined

  const where: any = {}
  if (status) where.status = status

  const skip = (page - 1) * limit
  const [reservations, total] = await prisma.$transaction([
    prisma.diningReservation.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip,
      take: limit,
    }),
    prisma.diningReservation.count({ where }),
  ])

  res.json({ reservations, total, page, limit })
})

export const adminUpdateDiningStatus = asyncHandler(
  async (req: Request, res: Response) => {
    const { id } = adminDiningIdParamSchema.parse(req.params)
    const { status } = adminDiningStatusSchema.parse(req).body

    const reservation = await prisma.diningReservation.update({
      where: { id },
      data: { status },
    })

    res.json({ reservation })
  }
)

// ===== Contact Messages (Admin) =====

export const adminListContact = asyncHandler(async (req: Request, res: Response) => {
  const page = parseInt(req.query.page as string) || 1
  const limit = parseInt(req.query.limit as string) || 20
  const status = req.query.status as string | undefined

  const where: any = {}
  if (status) where.status = status

  const skip = (page - 1) * limit
  const [messages, total] = await prisma.$transaction([
    prisma.contactMessage.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip,
      take: limit,
    }),
    prisma.contactMessage.count({ where }),
  ])

  res.json({ messages, total, page, limit })
})

export const adminMarkContactRead = asyncHandler(
  async (req: Request, res: Response) => {
    const { id } = adminContactIdParamSchema.parse(req.params)

    const message = await prisma.contactMessage.update({
      where: { id },
      data: { status: 'READ' },
    })

    res.json({ message })
  }
)

// ===== Reviews (Admin - Moderation) =====

export const adminListReviews = asyncHandler(async (req: Request, res: Response) => {
  const page = parseInt(req.query.page as string) || 1
  const limit = parseInt(req.query.limit as string) || 20
  const approved = req.query.approved as string | undefined

  const where: any = {}
  if (approved !== undefined) where.approved = approved === 'true'

  const skip = (page - 1) * limit
  const [reviews, total] = await prisma.$transaction([
    prisma.review.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip,
      take: limit,
    }),
    prisma.review.count({ where }),
  ])

  res.json({ reviews, total, page, limit })
})

export const adminModerateReview = asyncHandler(
  async (req: Request, res: Response) => {
    const { id } = adminReviewIdParamSchema.parse(req.params)
    const { approved } = adminReviewApproveSchema.parse(req).body

    const review = await prisma.review.update({
      where: { id },
      data: { approved },
    })

    res.json({ review })
  }
)

// ===== Offers (Admin) =====

export const adminCreateOffer = asyncHandler(async (req: Request, res: Response) => {
  const { body } = offerCreateSchema.parse(req)

  const offer = await prisma.offer.create({
    data: {
      title: body.title,
      subtitle: body.subtitle,
      discount: body.discount,
      description: body.description,
      validFrom: body.validFrom ? new Date(body.validFrom) : null,
      validTill: body.validTill ? new Date(body.validTill) : null,
      active: body.active,
      image: body.image,
    },
  })

  logger.info({ adminId: req.adminUser?.id, offerId: offer.id }, 'Admin created offer')
  res.status(201).json({ offer })
})

export const adminUpdateOffer = asyncHandler(async (req: Request, res: Response) => {
  const { id } = offerIdParamSchema.parse(req.params)
  const body = req.body

  const offer = await prisma.offer.update({
    where: { id },
    data: {
      ...(body.title !== undefined && { title: body.title }),
      ...(body.subtitle !== undefined && { subtitle: body.subtitle }),
      ...(body.discount !== undefined && { discount: body.discount }),
      ...(body.description !== undefined && { description: body.description }),
      ...(body.validFrom !== undefined && {
        validFrom: body.validFrom ? new Date(body.validFrom) : null,
      }),
      ...(body.validTill !== undefined && {
        validTill: body.validTill ? new Date(body.validTill) : null,
      }),
      ...(body.active !== undefined && { active: body.active }),
      ...(body.image !== undefined && { image: body.image }),
    },
  })

  res.json({ offer })
})

export const adminDeleteOffer = asyncHandler(async (req: Request, res: Response) => {
  const { id } = offerIdParamSchema.parse(req.params)

  const existing = await prisma.offer.findUnique({ where: { id } })
  if (!existing) {
    res.status(404).json({ error: 'Offer not found' })
    return
  }

  await prisma.offer.delete({ where: { id } })
  res.status(204).send()
})

// ===== Dashboard =====

export const adminDashboardStats = asyncHandler(async (req: Request, res: Response) => {
  const stats = await getDashboardStats()
  res.json(stats)
})

export const adminOccupancyReport = asyncHandler(async (req: Request, res: Response) => {
  const report = await getOccupancyReport()
  res.json(report)
})