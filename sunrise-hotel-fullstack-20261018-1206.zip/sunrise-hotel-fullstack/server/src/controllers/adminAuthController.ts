import { Request, Response, NextFunction } from 'express'
import { asyncHandler } from '../middleware/error'
import { adminLoginSchema } from '../middleware/validation'
import { prisma } from '../config/db'
import { config } from '../config/index'
import { logger } from '../utils/logger'
import bcrypt from 'bcryptjs'
import { v4 as uuidv4 } from 'uuid'

export const adminLogin = asyncHandler(async (req: Request, res: Response) => {
  const { body } = adminLoginSchema.parse({ body: req.body })
  const { email, password } = body

  const admin = await prisma.adminUser.findUnique({ where: { email } })
  if (!admin || !admin.isActive) {
    res.status(401).json({ error: 'Invalid credentials' })
    return
  }

  const valid = await bcrypt.compare(password, admin.passwordHash)
  if (!valid) {
    res.status(401).json({ error: 'Invalid credentials' })
    return
  }

  // Create session token
  const token = uuidv4()
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days

  await prisma.adminSession.create({
    data: {
      adminUserId: admin.id,
      tokenHash: token,
      expiresAt,
    },
  })

  await prisma.adminUser.update({
    where: { id: admin.id },
    data: { lastLoginAt: new Date() },
  })

  logger.info({ adminId: admin.id }, 'Admin login')

  // Set HTTP-only session cookie
  res.cookie('sessionToken', token, {
    httpOnly: true,
    secure: config.isProduction,
    sameSite: 'lax',
    maxAge: 7 * 24 * 60 * 60 * 1000,
    path: '/',
  })

  res.json({
    message: 'Login successful',
    admin: {
      id: admin.id,
      email: admin.email,
      role: admin.role,
    },
  })
})

export const adminLogout = asyncHandler(async (req: Request, res: Response) => {
  const token = req.cookies?.sessionToken
  if (token) {
    await prisma.adminSession.deleteMany({ where: { tokenHash: token } })
  }

  res.clearCookie('sessionToken', { path: '/', httpOnly: true, secure: config.isProduction, sameSite: 'lax' })
  res.json({ message: 'Logged out' })
})

export const adminMe = asyncHandler(async (req: Request, res: Response) => {
  res.json({
    admin: {
      id: req.adminUser!.id,
      email: req.adminUser!.email,
      role: req.adminUser!.role,
    },
  })
})

/**
 * Seed initial admin user (first-run setup)
 * Called by seed script
 */
export const createInitialAdmin = async (email: string, password: string, role: string = 'SUPER_ADMIN') => {
  const existing = await prisma.adminUser.findUnique({ where: { email } })
  if (existing) return existing

  const passwordHash = await bcrypt.hash(password, 12)

  const admin = await prisma.adminUser.create({
    data: { email, passwordHash, role },
  })

  logger.info({ adminId: admin.id }, 'Initial admin created')
  return admin
}