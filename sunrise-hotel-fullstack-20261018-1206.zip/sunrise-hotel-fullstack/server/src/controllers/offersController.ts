import { Request, Response } from 'express'
import { asyncHandler } from '../middleware/error'
import { prisma } from '../config/db'
import { logger } from '../utils/logger'

export const getOffers = asyncHandler(async (req: Request, res: Response) => {
  const now = new Date()

  const offers = await prisma.offer.findMany({
    where: {
      active: true,
      OR: [
        { validFrom: null },
        { validFrom: { lte: now } },
        { validTill: null },
        { validTill: { gte: now } },
      ],
    },
    orderBy: { createdAt: 'desc' },
  })

  res.json({
    offers: offers.map((o) => ({
      id: o.id,
      title: o.title,
      subtitle: o.subtitle,
      discount: o.discount,
      description: o.description,
      validFrom: o.validFrom,
      validTill: o.validTill,
      active: o.active,
      image: o.image,
    })),
  })
})