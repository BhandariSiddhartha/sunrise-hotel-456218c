import { Request, Response } from 'express'
import { asyncHandler } from '../middleware/error'
import {
  roomQuerySchema,
  roomIdParamSchema,
  roomAvailabilityQuerySchema,
} from '../middleware/validation'
import {
  checkAvailability,
  listBookings,
  getDashboardStats,
  getOccupancyReport,
} from '../services/bookingService'
import { prisma } from '../config/db'
import { logger } from '../utils/logger'

export const getRooms = asyncHandler(async (req: Request, res: Response) => {
  const parsed = roomQuerySchema.parse({ ...req.query })

  const where: any = {}
  if (parsed.active !== undefined) where.active = parsed.active
  if (parsed.type) where.type = parsed.type

  const rooms = await prisma.room.findMany({
    where,
    orderBy: { basePrice: 'asc' },
  })

  res.json({
    rooms: rooms.map((r) => ({
      id: r.id,
      name: r.name,
      type: r.type,
      description: r.description,
      capacity: r.capacity,
      basePrice: r.basePrice,
      currency: r.currency,
      size: r.size,
      beds: r.beds,
      view: r.view,
      images: r.images ? JSON.parse(r.images) : [],
      amenities: r.amenities ? JSON.parse(r.amenities) : [],
      active: r.active,
    })),
  })
})

export const getRoomById = asyncHandler(async (req: Request, res: Response) => {
  const { id } = roomIdParamSchema.parse(req.params)

  const room = await prisma.room.findUnique({ where: { id } })
  if (!room) {
    res.status(404).json({ error: 'Room not found' })
    return
  }

  res.json({
    id: room.id,
    name: room.name,
    type: room.type,
    description: room.description,
    capacity: room.capacity,
    basePrice: room.basePrice,
    currency: room.currency,
    size: room.size,
    beds: room.beds,
    view: room.view,
    images: room.images ? JSON.parse(room.images) : [],
    amenities: room.amenities ? JSON.parse(room.amenities) : [],
    active: room.active,
  })
})

export const getRoomAvailability = asyncHandler(
  async (req: Request, res: Response) => {
    const { checkIn, checkOut, guests, roomType } = roomAvailabilityQuerySchema.parse(
      req.query
    )

    const start = new Date(checkIn)
    const end = new Date(checkOut)

    if (end <= start) {
      res.status(400).json({ error: 'Check-out must be after check-in' })
      return
    }

    const result = await checkAvailability({
      checkIn: start,
      checkOut: end,
      guests,
      roomType,
    })

    res.json(result)
  }
)

export const createRoom = asyncHandler(async (req: Request, res: Response) => {
  const body = req.body
  const room = await prisma.room.create({
    data: {
      name: body.name,
      type: body.type,
      description: body.description,
      capacity: body.capacity,
      basePrice: body.basePrice,
      currency: body.currency || 'INR',
      size: body.size,
      beds: body.beds,
      view: body.view,
      images: body.images ? JSON.stringify(JSON.parse(body.images || '[]')) : '[]',
      amenities: body.amenities ? JSON.stringify(JSON.parse(body.amenities || '[]')) : '[]',
      active: body.active !== false,
    },
  })

  logger.info({ roomId: room.id }, 'Room created')
  res.status(201).json({ room })
})

export const updateRoom = asyncHandler(async (req: Request, res: Response) => {
  const { id } = roomIdParamSchema.parse(req.params)
  const body = req.body

  const room = await prisma.room.update({
    where: { id },
    data: {
      ...(body.name !== undefined && { name: body.name }),
      ...(body.type !== undefined && { type: body.type }),
      ...(body.description !== undefined && { description: body.description }),
      ...(body.capacity !== undefined && { capacity: body.capacity }),
      ...(body.basePrice !== undefined && { basePrice: body.basePrice }),
      ...(body.currency !== undefined && { currency: body.currency }),
      ...(body.size !== undefined && { size: body.size }),
      ...(body.beds !== undefined && { beds: body.beds }),
      ...(body.view !== undefined && { view: body.view }),
      ...(body.images !== undefined && {
        images: JSON.stringify(JSON.parse(body.images)),
      }),
      ...(body.amenities !== undefined && {
        amenities: JSON.stringify(JSON.parse(body.amenities)),
      }),
      ...(body.active !== undefined && { active: body.active }),
    },
  })

  res.json({ room })
})

export const deleteRoom = asyncHandler(async (req: Request, res: Response) => {
  const { id } = roomIdParamSchema.parse(req.params)

  const existing = await prisma.room.findUnique({ where: { id } })
  if (!existing) {
    res.status(404).json({ error: 'Room not found' })
    return
  }

  await prisma.room.delete({ where: { id } })
  res.status(204).send()
})