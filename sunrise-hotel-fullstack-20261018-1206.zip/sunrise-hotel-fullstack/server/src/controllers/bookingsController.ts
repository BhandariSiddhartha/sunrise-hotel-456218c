import { Request, Response } from 'express'
import { asyncHandler, AppError } from '../middleware/error'
import {
  bookingCreateSchema,
  bookingVerifySchema,
  bookingCancelSchema,
} from '../middleware/validation'
import {
  createBooking,
  getBookingByReference,
  cancelBooking,
  updateBookingStatus,
} from '../services/bookingService'
import { paymentService } from '../services/paymentService'
import { emailService } from '../services/emailService'
import { logger } from '../utils/logger'
import { config } from '../config/index'

export const createBookingController = asyncHandler(
  async (req: Request, res: Response) => {
    const { body } = bookingCreateSchema.parse(req)

    const checkIn = new Date(body.checkIn)
    const checkOut = new Date(body.checkOut)

    const result = await createBooking({
      firstName: body.firstName,
      lastName: body.lastName,
      email: body.email,
      phone: body.phone,
      checkIn,
      checkOut,
      adults: body.adults,
      children: body.children,
      roomType: body.roomType,
      rooms: body.rooms,
      specialRequest: body.specialRequest,
      idempotencyKey: body.idempotencyKey,
    })

    if (result.isDuplicate) {
      res.status(200).json({
        booking: result.booking,
        message: 'This booking was already submitted (duplicate request detected).',
      })
      return
    }

    const { booking } = result

    // Optional: create payment order if provider enabled
    let paymentInfo = null
    if (paymentService.isEnabled()) {
      paymentInfo = await paymentService.createOrder(
        booking.totalAmount,
        booking.currency,
        booking.reference
      )
    }

    // Send confirmation email (non-blocking)
    const emailHtml = emailService.templates.bookingConfirmation(
      booking.firstName,
      booking.reference,
      booking.checkIn.toISOString().split('T')[0],
      booking.checkOut.toISOString().split('T')[0],
      'Room',
      booking.totalAmount,
      booking.currency
    )
    emailService
      .sendEmail({
        to: booking.email,
        subject: emailHtml.subject,
        html: emailHtml.html,
        text: emailHtml.text,
      })
      .catch(() => {})

    logger.info({ bookingId: booking.id, reference: booking.reference }, 'Booking confirmation queued')

    res.status(201).json({
      booking: {
        id: booking.id,
        reference: booking.reference,
        roomId: booking.roomId,
        firstName: booking.firstName,
        lastName: booking.lastName,
        email: booking.email,
        phone: booking.phone,
        checkIn: booking.checkIn,
        checkOut: booking.checkOut,
        adults: booking.adults,
        children: booking.children,
        rooms: booking.rooms,
        roomType: booking.roomType,
        baseAmount: booking.baseAmount,
        taxAmount: booking.taxAmount,
        discountAmount: booking.discountAmount,
        totalAmount: booking.totalAmount,
        currency: booking.currency,
        status: booking.status,
        paymentStatus: booking.paymentStatus,
        specialRequest: booking.specialRequest,
        createdAt: booking.createdAt,
      },
      payment: paymentInfo,
      message: 'Booking created successfully. Use your reference to view or cancel your booking.',
    })
  }
)

export const getBooking = asyncHandler(async (req: Request, res: Response) => {
  const { body } = bookingVerifySchema.parse({ body: req.body })
  const { reference, email } = body

  const booking = await getBookingByReference(reference, email)

  res.json({
    booking: {
      reference: booking.reference,
      roomName: booking.room?.name,
      checkIn: booking.checkIn,
      checkOut: booking.checkOut,
      adults: booking.adults,
      children: booking.children,
      rooms: booking.rooms,
      roomType: booking.roomType,
      totalAmount: booking.totalAmount,
      currency: booking.currency,
      status: booking.status,
      paymentStatus: booking.paymentStatus,
      specialRequest: booking.specialRequest,
      createdAt: booking.createdAt,
    },
  })
})

export const cancelBookingController = asyncHandler(
  async (req: Request, res: Response) => {
    const { params, body } = bookingCancelSchema.parse({
      params: req.params,
      body: req.body,
    })
    const { reference } = params
    const { email, reason } = body

    const booking = await cancelBooking(reference, email, reason)

    // Send cancellation email (non-blocking)
    const cancelHtml = emailService.templates.bookingCancellation(
      booking.firstName,
      booking.reference
    )
    emailService
      .sendEmail({
        to: email,
        subject: cancelHtml.subject,
        html: cancelHtml.html,
        text: cancelHtml.text,
      })
      .catch(() => {})

    res.json({
      message: 'Booking cancelled successfully.',
      booking: {
        reference: booking.reference,
        status: booking.status,
        paymentStatus: booking.paymentStatus,
      },
    })
  }
)