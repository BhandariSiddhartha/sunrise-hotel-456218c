import { Request, Response } from 'express'
import { asyncHandler } from '../middleware/error'
import { reviewCreateSchema, reviewQuerySchema } from '../middleware/validation'
import { prisma } from '../config/db'
import { logger } from '../utils/logger'

export const getReviews = asyncHandler(async (req: Request, res: Response) => {
  const { approved } = reviewQuerySchema.parse(req.query)

  const reviews = await prisma.review.findMany({
    where: { approved },
    orderBy: { createdAt: 'desc' },
  })

  res.json({
    reviews: reviews.map((r) => ({
      id: r.id,
      name: r.name,
      rating: r.rating,
      comment: r.comment,
      location: r.location,
      approved: r.approved,
      createdAt: r.createdAt,
    })),
  })
})

export const createReview = asyncHandler(async (req: Request, res: Response) => {
  const { body } = reviewCreateSchema.parse(req)

  // Public submissions are NOT auto-approved - require moderation
  const review = await prisma.review.create({
    data: {
      name: body.name,
      rating: body.rating,
      comment: body.comment,
      location: body.location,
      approved: false,
    },
  })

  logger.info({ reviewId: review.id }, 'Review submitted (pending moderation)')

  res.status(201).json({
    message: 'Thank you for your review! It will be published after moderation.',
    review: {
      id: review.id,
      name: review.name,
      rating: review.rating,
      comment: review.comment,
      approved: review.approved,
    },
  })
})