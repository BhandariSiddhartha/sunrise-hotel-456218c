import { Request, Response } from 'express'
import { asyncHandler } from '../middleware/error'
import { diningCreateSchema } from '../middleware/validation'
import { prisma } from '../config/db'
import { emailService } from '../services/emailService'
import { logger } from '../utils/logger'

export const createDiningReservation = asyncHandler(
  async (req: Request, res: Response) => {
    const { body } = diningCreateSchema.parse(req)

    const reservation = await prisma.diningReservation.create({
      data: {
        name: body.name,
        email: body.email,
        phone: body.phone,
        date: new Date(body.date),
        time: body.time,
        guests: body.guests,
        occasion: body.occasion,
        specialRequest: body.specialRequest,
        status: 'PENDING',
      },
    })

    // Send confirmation email (non-blocking)
    const diningHtml = emailService.templates.diningConfirmation(
      body.name,
      body.date,
      body.time,
      body.guests
    )
    emailService
      .sendEmail({
        to: body.email,
        subject: diningHtml.subject,
        html: diningHtml.html,
        text: diningHtml.text,
      })
      .catch(() => {})

    logger.info({ reservationId: reservation.id }, 'Dining reservation created')

    res.status(201).json({
      reservation: {
        id: reservation.id,
        name: reservation.name,
        email: reservation.email,
        phone: reservation.phone,
        date: reservation.date,
        time: reservation.time,
        guests: reservation.guests,
        occasion: reservation.occasion,
        specialRequest: reservation.specialRequest,
        status: reservation.status,
        createdAt: reservation.createdAt,
      },
      message: 'Dining reservation submitted successfully. We will confirm shortly.',
    })
  }
)