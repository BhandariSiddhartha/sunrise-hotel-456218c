import { Request, Response } from 'express'
import { asyncHandler } from '../middleware/error'
import { contactCreateSchema } from '../middleware/validation'
import { prisma } from '../config/db'
import { emailService } from '../services/emailService'
import { logger } from '../utils/logger'

export const createContactMessage = asyncHandler(
  async (req: Request, res: Response) => {
    const { body } = contactCreateSchema.parse(req)

    const message = await prisma.contactMessage.create({
      data: {
        name: body.name,
        email: body.email,
        subject: body.subject,
        message: body.message,
        phone: body.phone,
        status: 'NEW',
      },
    })

    // Send receipt email (non-blocking)
    const contactHtml = emailService.templates.contactReceipt(
      body.name,
      body.subject || 'No subject'
    )
    emailService
      .sendEmail({
        to: body.email,
        subject: contactHtml.subject,
        html: contactHtml.html,
        text: contactHtml.text,
      })
      .catch(() => {})

    logger.info({ contactId: message.id }, 'Contact message created')

    res.status(201).json({
      message: 'Thank you for contacting Sunrise Hotels & Resorts. We will get back to you soon.',
      contact: {
        id: message.id,
        name: message.name,
        email: message.email,
        subject: message.subject,
        status: message.status,
        createdAt: message.createdAt,
      },
    })
  }
)